package com.example.copy_trader_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
