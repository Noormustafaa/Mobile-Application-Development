import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class SearchTradersScreen extends StatefulWidget {
  const SearchTradersScreen({super.key});

  @override
  State<SearchTradersScreen> createState() => _SearchTradersScreenState();
}

class _SearchTradersScreenState extends State<SearchTradersScreen> {
  final primaryfont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600, color: Colors.black, fontFamily: 'Poppins');
  final secondaryfont = TextStyle(fontSize: 10.sp, fontWeight: FontWeight.w400, color: Colors.grey, fontFamily: 'Arial');
  final percentagefont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500, color: Color(0xFFC3FFC3), fontFamily: 'Poppins');
  final searchbarfont = TextStyle(fontSize: 10.sp, fontWeight: FontWeight.w400, color: Color(0xFF6C757D), fontFamily: 'Poppins');

  final List<String> filters = ["All", "Top Performing", "Win Rate", "ROI", "Low Risk"];

  int selectedFilterIndex = 0;

  int _selectedIndex = 1;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actionsPadding: EdgeInsets.all(10.r),
        title: Text('Explores Traders', style: primaryfont.copyWith(fontSize: 20.sp)),
        backgroundColor: Colors.white,
        elevation: 0,
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: Icon(Icons.settings_outlined, color: Colors.black, size: 24.sp),
            onPressed: () => Navigator.pushNamed(context, '/profile_settings'),
          ),
          SizedBox(width: 10.w),
        ],
      ),

      resizeToAvoidBottomInset: true,
      backgroundColor: Colors.white,
      //backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      body: SafeArea(
        child: LayoutBuilder(
          builder: (context, constraints) => SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    
                    TextField(
                      decoration: InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: "Search Traders by name, ROI, risk level",
                        hintStyle: searchbarfont,
                    
                        suffixIcon: IconButton(
                          icon: Icon(Icons.tune),
                          onPressed: () {
                            // Open filter options
                            Navigator.pushNamed(context, '/filter_screen');
                          },
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12.r),
                          borderSide: BorderSide.none,
                        ),
                        filled: true,
                        fillColor: Theme.of(context).cardColor.withOpacity(0.1),
                      ),
                    ),

                    SizedBox(height: 16.h),

                   _buildFilterChips(),

                    SizedBox(height: 16.h),
                    Text(
                      'For You',
                      style: primaryfont.copyWith(fontSize: 18.sp,                        
                        color: Theme.of(context).textTheme.bodyLarge!.color,
                      ),
                    ),
                    SizedBox(height: 12.h),
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: 4,
                      itemBuilder: (context, index) => _buildTraderCard(index),
                    ),
                    SizedBox(height: 24.h),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped)
    );
  }

  Widget _buildFilterChips() {
    return Container(
      height: 40.h,
      decoration: BoxDecoration(
        color: Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(color: Colors.grey.shade200, blurRadius: 6, offset: const Offset(0, 3)),
        ],
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final isSelected = index == selectedFilterIndex;
          return Padding(
            padding: EdgeInsets.only(right: 8.w),
            child: ChoiceChip(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
              label: Text(filters[index], style: secondaryfont.copyWith(color: isSelected ? Colors.white : Colors.black)),
              selected: isSelected,
              onSelected: (_) {
                setState(() {
                  selectedFilterIndex = index;
                });
              },
              selectedColor: Color(0xFF0B5638),
              backgroundColor: Colors.white,
            ),
          );
        },
      ),
    );
  }

  Widget _buildTraderCard(int index) {
    bool isGraphGreen = index % 2 == 0;

    return Container(
      height: 100.h,
      margin: EdgeInsets.only(bottom: 12.h),
      padding: EdgeInsets.all(12.r),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(
            color: Colors.black12,
            blurRadius: 6,
            offset: Offset(0, 2),
          )
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 1. Image (fixed)
          ClipRRect(
            borderRadius: BorderRadius.circular(8.r),
            child: Image.asset(
              'assets/images/face_id.png',   //change to your trader image
              height: 60.w,
              width: 60.w,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 60.w,
                  width: 60.w,
                  color: Colors.grey.shade300,
                  child: Icon(Icons.person, color: Colors.grey.shade600),
                );
              },
            ),
          ),

          SizedBox(width: 12.w),

          // 2. Expanded middle content
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Maria Khan',
                  style: primaryfont,
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                SizedBox(height: 2.h),
                Text(
                  '1.5k Followers',
                  style: secondaryfont.copyWith(fontSize: 8.sp),
                  overflow: TextOverflow.ellipsis,
                  maxLines: 1,
                ),
                Text(
                  '90% win rate',
                  style: secondaryfont.copyWith(fontSize: 8.sp, color: Color(0xFF71DF71)),
                  overflow: TextOverflow.ellipsis,
                ),
                Text(
                  'RR per Trade 1:2.5',
                  style: primaryfont.copyWith(fontWeight: FontWeight.w400, fontSize: 6.sp, color: Color(0xFF0573B8)),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),


          // 3. Stats section (keep width tight)
          Expanded(
            flex: 2,
          child:  Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                '+45% month',
                style: percentagefont.copyWith(color: Color(0xFF257D25)),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              SizedBox(height: 4.h),
              Text("Net Profit", style: secondaryfont.copyWith(fontSize: 6.sp)),
              Text(
                '\$2.3M',
                style: percentagefont.copyWith(fontSize: 8.sp, color: Color(0xFF006058)),
                overflow: TextOverflow.ellipsis,
                maxLines: 1,
              ),
              SizedBox(height: 4.h),
              Icon(
                isGraphGreen ? Icons.show_chart : Icons.stacked_line_chart,
                color: isGraphGreen ? Colors.green : Colors.red,
                size: 20.sp,
              ),
            ],
          ),),
        ],
      ),
    );
  }




}
