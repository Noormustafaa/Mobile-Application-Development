import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:copy_trader_app/HomeScreens/checkWithdrawAndDeposit.dart';

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});

  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  String walletID = "kfkdkfakgkdgkdgksdfekkrrre12errrc";

  final titlefont = TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w600, fontFamily: 'Poppins', color: Colors.black);
  final subtitlefont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w400, color: Colors.white, fontFamily: 'Arial');
  final secondaryfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500, color: Color(0xFFDFDEDE), fontFamily: 'Poppins');
  
  int _selectedIndex = 3;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            leading:  IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pop(context);
              },
              ),
            title: Text('Wallet', style: titlefont),
            centerTitle: true,
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            elevation: 0,
          ),

          body: Padding(
            padding: EdgeInsets.all(16.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Wallet Balance Card
                Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(12.r),
                  decoration: BoxDecoration(
                    color: Color(0xFF005332),
                    borderRadius: BorderRadius.circular(16.r),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Text("Wallet Balance", style: subtitlefont),
                      SizedBox(height: 6.h),
                      Text("\$4,500", style: TextStyle(color: Colors.white, fontSize: 25.sp, fontWeight: FontWeight.w700, fontFamily: 'Poppins')),
                      Text("Total Balance",style: subtitlefont.copyWith(fontSize: 12.sp)),
                      SizedBox(height: 16.h),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          Column(
                            children: [
                              Text("Available", style: secondaryfont),
                              Text("\$12,50", style: titlefont.copyWith(fontSize: 14.sp, color: Colors.white)),
                            ],
                          ),
                          Column(
                            children: [
                              Text("Invested", style: secondaryfont),
                              Text("\$7,50", style: titlefont.copyWith(fontSize: 14.sp, color: Colors.white)),
                            ],
                          ),
                        ],
                      ),
                      SizedBox(height: 16.h),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          OutlinedButton(
                            onPressed: () {
                              // Navigate to merged screen with withdraw tab active
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => WithdrawTransactionsScreen(initialIsDeposit: false),
                                ),
                              );
                            },
                            style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: BorderSide(color: Colors.white)),
                            child: Text("Withdraw", style: secondaryfont.copyWith(color: Colors.white, fontSize: 14.sp)),
                          ),
                          SizedBox(width: 12.w),
                          ElevatedButton(
                            onPressed: () {
                              // Navigate to merged screen with deposit tab active
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => WithdrawTransactionsScreen(initialIsDeposit: true),
                                ),
                              );
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color(0xFF009400),
                              foregroundColor: Colors.white,
                            ),
                            child: Text("Deposit", style: secondaryfont.copyWith(color: Colors.white, fontSize: 14.sp)),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
                SizedBox(height: 10.h),

                // Wallet ID
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(8.r),
                    border: Border.all(color: Color(0xFFEBEBEB)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Text(
                           'Wallet ID \n $walletID',
                          style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w500, color: Color(0xFF005332), fontFamily: 'Poppins'),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Icon(Icons.copy, size: 20.sp)
                    ],
                  ),
                ),
                

                // Transactions Header
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Your Transactions", style: titlefont.copyWith(fontSize: 14.sp)),
                    TextButton(onPressed: (){
                      // Navigate to merged screen with default view (withdraw)
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => WithdrawTransactionsScreen(),
                        ),
                      );
                    },
                     child:  Text("See all", style: TextStyle(color: Colors.green, fontSize: 10.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w400)),)

                  ],
                ),

                // Transactions List
                Expanded(
                  child: ListView(
                    children: [
                      _transactionTile("Cash Deposit", "+\$500", "12/6/2025", "3445262", true),
                      _transactionTile("Cash Withdraw", "-\$500", "12/6/2025", "3445262", false),
                      _transactionTile("Cash Deposit", "+\$500", "12/6/2025", "3445262", true),
                      _transactionTile("Cash Withdraw", "-\$500", "12/6/2025", "3445262", false),
                    ],
                  ),
                ),
              ],
            ),
          ),
          bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped)
        );
  }

  Widget _transactionTile(String title, String amount, String date, String id, bool isDeposit) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 6.h),
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10.r),
        border: Border.all(color: Color(0xFFEBEBEB)),
      ),
      child: Row(
        children: [
          Icon(
            isDeposit ? FontAwesomeIcons.download : FontAwesomeIcons.upload,
            color: isDeposit ? Colors.green : Colors.red,
            size: 28.sp,
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: secondaryfont.copyWith(fontSize: 14.sp, color: Colors.black)),
                Text("$date    $id", style: secondaryfont.copyWith(fontSize: 14.sp, color: Colors.grey)),
              ],
            ),
          ),
          Text(
            amount,
            style: titlefont.copyWith(
              fontSize: 16.sp,
              color: isDeposit ? Colors.green : Colors.red,
            ),
          )
        ],
      ),
    );
  }
}
