import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class InvestScreen extends StatefulWidget {
  const InvestScreen({super.key});

  @override
  State<InvestScreen> createState() => _InvestScreenState();
}

class _InvestScreenState extends State<InvestScreen> {
  int? selectedAmount;
  final List<int> amountOptions = [100, 500, 1000, 2500, 5000];
  final TextEditingController customAmountController = TextEditingController();
  
  final primaryColor = Color(0xFF0B5638);
  final titlefont = TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w600, fontFamily: 'Poppins', color: Colors.black);
  final subtitlefont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, color: Color(0xFF686868), fontFamily: 'Arial');
  final secondaryfont = TextStyle(fontSize: 10.sp, fontWeight: FontWeight.w500, color: Color(0xFF6B706B), fontFamily: 'Poppins');

  @override
  void dispose() {
    customAmountController.dispose();
    super.dispose();
  }
  
  int _selectedIndex = 1;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.all(16.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Trader Info Card
                Container(
                  padding: EdgeInsets.all(15.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: Colors.grey[300]!),
                  ),
                  child:  Column(
                children: [
                  Row(children: [
                    CircleAvatar(
                        radius: 30.r,
                        backgroundImage: AssetImage("assets/images/trader_profile.jpg"),
                        onBackgroundImageError: (_, __) {
                         Icon(Icons.person, color: Colors.grey[600], size: 20.r);
                        },
                      ),
                      SizedBox(width: 12.w),
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Maria Khan", style: titlefont),
                            Text("1.5k Followers", style: subtitlefont),
                     ]),

                  ],),
                  SizedBox(height: 10.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                          Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("\$6900", style: titlefont.copyWith(fontSize: 19.sp)),
                                    Text("+45% month", style: secondaryfont.copyWith(color: Colors.green)),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text("1:2.3", style: titlefont.copyWith(color: Color(0xFF005286), fontSize: 19.sp)),
                                    Text("RR Ratio", style: secondaryfont),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text("80%", style: titlefont.copyWith(color: Colors.green, fontSize: 19.sp)),
                                    Text("Win Rate", style: secondaryfont),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text("13.8%", style: titlefont.copyWith(color: Colors.red, fontSize: 19.sp)),
                                    Text("Downtime", style: secondaryfont),
                                  ],
                       ),

                    ],
                  )
                ],
               ),
                ),
                SizedBox(height: 24.h),

                // Select Amount
                Text("Select Invest Amount", style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w400, fontFamily: 'Poppins')),
                SizedBox(height: 12.h),

                Wrap(
                  spacing: 10.w,
                  runSpacing: 10.h,
                  children: List.generate(amountOptions.length, (index) {
                    final amount = amountOptions[index];
                    final isSelected = selectedAmount == amount;
                    return ChoiceChip(
                      label: Text("\$$amount"),
                      selected: isSelected,
                      onSelected: (_) {
                        setState(() {
                          selectedAmount = amount;
                          customAmountController.clear();
                        });
                      },
                      selectedColor: primaryColor,
                      backgroundColor: Colors.white,
                      labelStyle: TextStyle( fontFamily: 'Montserrat',fontSize: 14.sp, fontWeight: FontWeight.w400,
                        color: isSelected ? Colors.white : Colors.black,
                      ),
                    );
                  }),
                ),
                SizedBox(height: 20.h),

                // Custom Amount
                TextField(
                  controller: customAmountController,
                  keyboardType: TextInputType.number,
                  onChanged: (value) {
                    setState(() {
                      selectedAmount = null;
                    });
                  },
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.attach_money, color: Colors.green[300]),
                    hintText: "Enter Custom Amount",
                    hintStyle: subtitlefont.copyWith(fontSize: 14.sp, color: Color(0xFFBCBCBC)),
                    filled: true,
                    fillColor: Colors.white,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12.r),
                      borderSide: BorderSide(color: Colors.grey, width: 1),

                    ),
                  ),
                ),
                SizedBox(height: 8.h),
                Row(
                  children: [
                    Expanded(
                      child: Text("Min investment: \$100", style: TextStyle(color: Color(0xff79A292), fontSize: 12.sp)),
                    ),
                    Expanded(
                      child: Text("Max investment: \$50,000", style: TextStyle(color: Color(0xff79A292), fontSize: 12.sp), textAlign: TextAlign.end),
                    ),
                  ],
                ),
                SizedBox(height: 32.h),

                // Invest Button
                SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        _handleInvest();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor,
                        padding: EdgeInsets.symmetric(
                            horizontal: 40.w, vertical: 12.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        minimumSize: Size(double.infinity, 52.h),
                      ),
                      child: Text(
                        'Invest',
                        style: secondaryfont.copyWith(
                          color: Colors.white,
                          fontSize: 22.sp,
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped),
      );
  }

  void _handleInvest() {
    int? amount = selectedAmount;

    if (customAmountController.text.isNotEmpty) {
      final input = int.tryParse(customAmountController.text);
      if (input == null || input < 100 || input > 50000) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("Enter amount between \$100 and \$50,000")),
        );
        return;
      }
      amount = input;
    }

    if (amount == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Please select or enter an amount")),
      );
      return;
    }

    // Perform investment logic
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Invested \$${amount.toString()}")),
    );
  }
}
