import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';
import 'package:copy_trader_app/charts/line_chart.dart';

class InvestedTraderProfileScreen extends StatefulWidget {
  const InvestedTraderProfileScreen({super.key});

  @override
  State<InvestedTraderProfileScreen> createState() => _InvestedTraderProfileScreenState();
}

class _InvestedTraderProfileScreenState extends State<InvestedTraderProfileScreen> {
  bool showAdvancedMetrics = false;
  
  final titlefont = TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w600, fontFamily: 'Poppins', color: Colors.black);
  final subtitlefont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, color: Color(0xFF686868), fontFamily: 'Arial');
  final secondaryfont = TextStyle(fontSize: 10.sp, fontWeight: FontWeight.w500, color: Color(0xFF6B706B), fontFamily: 'Poppins');
  final chipfont = TextStyle(fontSize: 8.sp, fontWeight: FontWeight.w500, color: Colors.white, fontFamily: 'Poppins');
  final monthlyreturnfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, color: Colors.black, fontFamily: 'Poppins');

  final List<FlSpot> liveChartData = [
                FlSpot(0, 10000),
                FlSpot(1, 9000),
                FlSpot(2, 7000),
                FlSpot(3, 3000),
                FlSpot(4, 4000),
                FlSpot(5, 8000),
                FlSpot(6, 9000),
                FlSpot(7, 8500),
                FlSpot(8, 10000),
                FlSpot(9, 11000),
                FlSpot(10, 7500),
                FlSpot(11, 2000),
   ];

  int _selectedIndex = 1;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.pushNamed(context, '/search_trader');
            },
          ),
          title: const Text(""),
          actions: [
            IconButton(
              icon: const Icon(Icons.share_outlined),
              onPressed: () {
                // Implement share functionality
              },
            ),
            SizedBox(width: 8.w),
          ],
          elevation: 0,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
        ),
       body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                SizedBox(height: 24.h),
                _buildEquityGraph(),
                SizedBox(height: 16.h),
                _buildTradingStrategy(),
                SizedBox(height: 16.h),
                _buildMonthlyPerformanceTrends(),
                SizedBox(height: 16.h),
                 _buildRecentTrades(),
                SizedBox(height: 20.h),
                _buildInvestmentButtons(),
                SizedBox(height: 20.h),
              ],
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped)
      );
  }

  Widget _buildHeader() {
    return  Column(
                children: [
                  Row(children: [
                    CircleAvatar(
                        radius: 30.r,
                        backgroundImage: AssetImage("assets/images/trader_profile.jpg"),
                        onBackgroundImageError: (_, __) {
                         Icon(Icons.person, color: Colors.grey[600], size: 20.r);
                        },
                      ),
                      SizedBox(width: 12.w),
                      Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Maria Khan", style: titlefont),
                            Text("1.5k Followers", style: subtitlefont),
                     ]),

                  ],),
                  SizedBox(height: 10.h),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                          Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("\$6900", style: titlefont.copyWith(fontSize: 19.sp)),
                                    Text("+45% month", style: secondaryfont.copyWith(color: Colors.green)),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text("1:2.3", style: titlefont.copyWith(color: Color(0xFF005286), fontSize: 19.sp)),
                                    Text("RR Ratio", style: secondaryfont),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text("80%", style: titlefont.copyWith(color: Colors.green, fontSize: 19.sp)),
                                    Text("Win Rate", style: secondaryfont),
                                  ],
                                ),
                                Column(
                                  children: [
                                    Text("13.8%", style: titlefont.copyWith(color: Colors.red, fontSize: 19.sp)),
                                    Text("Downtime", style: secondaryfont),
                                  ],
                       ),

                    ],
                  )
                ],
    );
  }

  Widget _buildEquityGraph() {
    return Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16.r),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Equity Graph", style: titlefont.copyWith(fontSize: 16.sp)),
                      SizedBox(height: 12.h),
                      TraderLineChart(
                  spots: liveChartData, // <-- this should come from API, provider, or state
                  )
         ]),
    );
  }

  Widget _buildTradingStrategy() {
    return _card(
       title: "Trading Strategy",
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Momentum based Swing trader focusing on major currency pairs during high volatility period",
                      style: TextStyle(fontSize: 13.sp),
                    ),
                    SizedBox(height: 12.h),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Text("Trading Style", style: chipfont.copyWith(color: Colors.grey)),
                        Text("Experience", style: chipfont.copyWith(color: Colors.grey)),
                        Text("Speciality", style: chipfont.copyWith(color: Colors.grey)),
                      ],
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _chip("Swing Trader", color: Color(0xFF217252)),
                        _chip("5+ years", color: Colors.white),
                        _chip("Currency Pair", color: Colors.white),
                      ],
                    )
                  ],
                ),
    );
  }

  Widget _buildMonthlyPerformanceTrends() {
    return _card(
       title: "Monthly Performance Trends",
                subtitle: "Average Monthly Returns over the Past 3 years",
                child: SizedBox(
                  height: 200.h,
                  child: BarChart(
                    BarChartData(
                      titlesData: FlTitlesData(
                        bottomTitles: AxisTitles(
                          sideTitles: SideTitles(
                            showTitles: true,
                            getTitlesWidget: (value, meta) {
                              const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                              return Text(months[value.toInt()], style: TextStyle(fontSize: 10.sp));
                            },
                          ),
                        ),
                        leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                        topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      ),
                      barGroups: List.generate(12, (index) {
                        return BarChartGroupData(
                          x: index,
                          barRods: [
                            BarChartRodData(toY: (index % 6 + 2) * 10.0, color: Color(0xFF00A968), width: 6.w),
                            BarChartRodData(toY: (index % 5 + 1) * 12.0, color: Color(0xFF8979FF), width: 6.w),
                          ],
                        );
                      }),
                      borderData: FlBorderData(show: false),
                      gridData: FlGridData(show: false),
                    ),
                  ),
                ),
    );
  }

  Widget _buildRecentTrades() {
    return _card(
      title: "Recent Trades",
      child: Column(
        children: List.generate(3, (index) {
          return Padding(
            padding: EdgeInsets.symmetric(vertical: 6.h),
            child: Row(
              children: [
                Icon(Icons.calendar_today_outlined, size: 16.sp),
                SizedBox(width: 10.w),
                Text("2024-12-13", style: TextStyle(fontSize: 14.sp)),
                const Spacer(),
                Text("+\$500", style: TextStyle(fontSize: 14.sp, color: Colors.green)),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildInvestmentButtons() {
    return Column(
      children: [
        ElevatedButton(
          onPressed: () {
            //add more investement functionality here
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: Color(0xFF0B5638),
            padding: EdgeInsets.symmetric(vertical: 14.h),
            minimumSize: Size(double.infinity, 0),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.r)),
          ),
          child: Text("Add more investment", style: secondaryfont.copyWith(color: Colors.white, fontSize: 20.sp)),
        ),
        SizedBox(height: 12.h),
        OutlinedButton(
          onPressed: () {},
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: Color(0xFFE9E9E9)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.r)),
            padding: EdgeInsets.symmetric(vertical: 14.h),
            minimumSize: Size(double.infinity, 0),
          ),
          child: Text("Withdraw Profit", style: secondaryfont.copyWith(fontSize: 20.sp, color: Colors.black)),
        ),
        SizedBox(height: 10.h),
        OutlinedButton(
          onPressed: () {},
          style: OutlinedButton.styleFrom(
            side: const BorderSide(color: Color(0xFFE9E9E9)),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.r)),
            padding: EdgeInsets.symmetric(vertical: 14.h),
            minimumSize: Size(double.infinity, 0),
          ),
          child: Text("Withdraw Full Investment", style: secondaryfont.copyWith(fontSize: 20.sp, color: Colors.black)),
        ),
      ],
    );
  }

 
  Widget _card({required String title, String? subtitle, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.all(14.w),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.bold)),
          if (subtitle != null)
            Padding(
              padding: EdgeInsets.only(top: 4.h),
              child: Text(subtitle, style: TextStyle(fontSize: 12.sp, color: Colors.grey)),
            ),
          SizedBox(height: 10.h),
          child,
        ],
      ),
    );
  }

 Widget _chip(String label, {Color? color}) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10.w, vertical: 6.h),
      decoration: BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(20.r),
      ),
      child: Text(label, style: chipfont.copyWith(fontWeight: FontWeight.w600, color: color == Colors.white ? Colors.black : Colors.white)),
    );
  }
}
