import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<String> filters = ['All', 'Top Performing', 'Win Rate', 'ROI', 'Low Risk'];

  final primaryfont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w600, color: Colors.black, fontFamily: 'Poppins');
  final secondaryfont = TextStyle(fontSize: 10.sp, fontWeight: FontWeight.w400, color: Colors.grey, fontFamily: 'Arial');
  final percentagefont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500, color: Color(0xFFC3FFC3), fontFamily: 'Poppins');


  int selectedFilterIndex = 0;
  int _selectedIndex=0;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildTopCard(),
                SizedBox(height: 20.h),
                _buildFilterChips(),
                SizedBox(height: 20.h),
                Text(
                  'Top Performing Traders',
                  style: primaryfont.copyWith(fontSize: 18.sp),
                ),
                SizedBox(height:20.h),
                ListView.builder(
                  itemCount: 4,
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemBuilder: (context, index) => _buildTraderCard(),
                ),
              ],
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped)
      );
  }

  Widget _buildTopCard() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: const Color(0xFF217252),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/face_id.png'),
            radius: 24.r,
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Hi Maria", style: primaryfont.copyWith(fontWeight: FontWeight.w500, color: Colors.white)),
                SizedBox(height: 4.h),
                Text("Portfolio", style: percentagefont.copyWith(fontSize: 12.sp, color: Colors.white, fontWeight: FontWeight.w400)),
                Text("\$457,000", style: primaryfont.copyWith(fontSize: 20.sp, color: Colors.white,)),
              ],
            ),
          ),
          Column(
            children: [
              IconButton(onPressed: (){
                Navigator.pushNamed(context, '/profile_settings');
              }, icon: Icon(Icons.settings_outlined, color: Colors.white, size: 20.r)),
              SizedBox(height: 20.h),
              Text("+40%", style: percentagefont),
              Text("+5000", style: percentagefont.copyWith(color: Colors.white)),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildFilterChips() {
    return Container(
      height: 40.h,
      decoration: BoxDecoration(
        color: Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(20.r),
        boxShadow: [
          BoxShadow(color: Colors.grey.shade200, blurRadius: 6, offset: const Offset(0, 3)),
        ],
      ),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: filters.length,
        itemBuilder: (context, index) {
          final isSelected = index == selectedFilterIndex;
          return Padding(
            padding: EdgeInsets.only(right: 8.w),
            child: ChoiceChip(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20.r)),
              label: Text(filters[index], style: secondaryfont.copyWith(color: isSelected ? Colors.white : Colors.black)),
              selected: isSelected,
              onSelected: (_) {
                setState(() {
                  selectedFilterIndex = index;
                });
              },
              selectedColor: Color(0xFF0B5638),
              backgroundColor: Colors.white,
            ),
          );
        },
      ),
    );
  }

  Widget _buildTraderCard() {
    return Container(
      height: 100.h,
      margin: EdgeInsets.only(bottom: 12.h),
      padding: EdgeInsets.all(12.r),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        boxShadow: [
          BoxShadow(color: Colors.grey.shade200, blurRadius: 6, offset: const Offset(0, 3)),
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8.r),
            child: Image.asset(
              'assets/images/face_id.png',     //change to your trader image
              height: 50.h,
              width: 50.w,
              fit: BoxFit.cover,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 50.h,
                  width: 50.w,
                  color: Colors.grey.shade300,
                  child: Icon(Icons.person, color: Colors.grey.shade600),
                );
              },
            ),
          ),
          SizedBox(width: 12.w),

          // LEFT COLUMN
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Maria Khan", style: primaryfont, overflow: TextOverflow.ellipsis, maxLines: 1),
                Text("1.5k Followers", style: secondaryfont.copyWith(fontSize: 8.sp), overflow: TextOverflow.ellipsis, maxLines: 1),
                Text("90% win rate", style: secondaryfont.copyWith(fontSize: 8.sp, color: Color(0xFF71DF71)), overflow: TextOverflow.ellipsis, maxLines: 1),
                Text("RR per Trade 1:2.3", style: primaryfont.copyWith(fontWeight: FontWeight.w400, fontSize: 6.sp, color: Color(0xFF0573B8)), overflow: TextOverflow.ellipsis, maxLines: 1),
              ],
            ),
          ),

          //RIGHT COLUMN 
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text("+45% month", style: percentagefont.copyWith(color: Color(0xFF257D25))),
                SizedBox(height: 4.h),
                Text("Net Profit", style: secondaryfont.copyWith(fontSize: 6.sp)),
                Text("\$2.3M", style: percentagefont.copyWith(fontSize: 8.sp, color: Color(0xFF006058))),
                SizedBox(height: 4.h),
                Icon(Icons.trending_up, color: Color(0xFF71DF71), size: 20.r),
              ],
            ),
          ),
        ],
      ),

    );
  }
}
