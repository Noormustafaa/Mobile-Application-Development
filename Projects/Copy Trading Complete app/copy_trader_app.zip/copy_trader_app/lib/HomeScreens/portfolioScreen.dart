import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';
import 'package:copy_trader_app/charts/pie_chart.dart';
import 'package:copy_trader_app/charts/line_chart.dart';

class ProfitSection {
  final String label;
  final double value;
  final Color color;

  ProfitSection({required this.label, required this.value, required this.color});
}

class PortfolioScreen extends StatefulWidget {
  const PortfolioScreen({super.key});

  @override
  State<PortfolioScreen> createState() => _PortfolioScreenState();
}

class _PortfolioScreenState extends State<PortfolioScreen> {
  final titlefont = TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w600, color: Colors.black, fontFamily: 'Poppins');
  final subtitlefont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w400, color: Colors.white, fontFamily: 'Poppins');

  // Add your dynamic pie chart data here
  final List<Map<String, dynamic>> chartData = [
    {'title': 'Investor', 'value': 60.0, 'color': Colors.blue},
    {'title': 'Company', 'value': 10.0, 'color': Colors.orange},
    {'title': 'Trader', 'value': 30.0, 'color': Colors.green},
  ];

   final List<FlSpot> liveChartData = [
                FlSpot(0, 10000),
                FlSpot(1, 9000),
                FlSpot(2, 7000),
                FlSpot(3, 3000),
                FlSpot(4, 4000),
                FlSpot(5, 8000),
                FlSpot(6, 9000),
                FlSpot(7, 8500),
                FlSpot(8, 10000),
                FlSpot(9, 11000),
                FlSpot(10, 7500),
                FlSpot(11, 2000),
   ];

  int _selectedIndex = 2;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          leading: const Icon(Icons.arrow_back),
          title: Text("Portfolio Overview", style: titlefont),
          centerTitle: true,
          backgroundColor: Colors.white,
          foregroundColor: Colors.black,
          elevation: 0,
          actions: [
            IconButton(
              icon: const Icon(Icons.settings_outlined),
              onPressed: () {
                Navigator.pushNamed(context, '/profile_settings');
              },
            ),
          ],
        ),
        body: Padding(
          padding: EdgeInsets.all(16.w),
          child: SingleChildScrollView(
            child: Column(
              children: [
                _portfolioCard(),
                SizedBox(height: 16.h),
                _lineChartSection(),
                SizedBox(height: 20.h),
                _pieChartSection(),
                SizedBox(height: 20.h),
                _investmentListSection(),
              ],
            ),
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar( selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped, ),
      );
  }

  Widget _portfolioCard() {
    return Container(
      padding: EdgeInsets.all(16.w),
      decoration: BoxDecoration(
        color: Color(0xFF005332),
        borderRadius: BorderRadius.circular(16.r),
      ),
      child: Column(
        children: [
          Text("Total Portfolio Value", style: subtitlefont),
          SizedBox(height: 8.h),
          Text("\$457,000", style: titlefont.copyWith(fontSize: 24.sp, color: Colors.white)),
          SizedBox(height: 4.h),
          Text("+\$1,022.5 (+10.3%)", style: TextStyle(color: Colors.greenAccent, fontSize: 10.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w500)),
          SizedBox(height: 16.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Column(
                children: [
                  Text("Active", style: TextStyle(color: Colors.white, fontSize: 12.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w500)),
                  Text("3", style: titlefont.copyWith(fontSize: 14.sp, color: Colors.white)),
                ],
              ),
              Column(
                children: [
                  Text("Monthly", style: TextStyle(color: Colors.white, fontSize: 12.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w500)),
                  Text("+4.2%", style: titlefont.copyWith(fontSize: 14.sp, color: Colors.white)),
                ],
              ),
            ],
          )
        ],
      ),
    );
  }
 
  Widget _lineChartSection() {
    return Container(
                  width: double.infinity,
                  padding: EdgeInsets.all(16.r),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      TraderLineChart(
                  spots: liveChartData, // <-- this should come from API, provider, or state
                  )
         ]),
    );
    
  }

  Widget _pieChartSection() {
    return  Container(
                  padding: EdgeInsets.all(13.r),
                  decoration: BoxDecoration(
                     color: Colors.white,
                    borderRadius: BorderRadius.circular(12.r),
                    boxShadow: [BoxShadow(color: Colors.grey.shade300, blurRadius: 6.r)],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Profit Breakdown", style: titlefont.copyWith(fontSize: 14.sp,)),
                      SizedBox(height: 8.h),
                      CustomPieChart(data: chartData), // ← use the widget here
                    ],
                  ),
    );// Passed dynamic data here
  }

 
                 
  Widget _investmentListSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text("Your Investments", style: titlefont.copyWith(fontSize: 14.sp)),
            TextButton(onPressed: (){  // Check all transactions
            },
             child:  Text("See all", style: TextStyle(color: Colors.green, fontSize: 10.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w400)),)
          ],
        ),
        _investmentTile(),
        _investmentTile(),
        _investmentTile(),
      ],
    );
  }

  Widget _investmentTile() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 6.h),
      padding: EdgeInsets.all(12.w),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: Color(0xFFEBEBEB)),
        borderRadius: BorderRadius.circular(12.r),
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 20.r,
            backgroundColor: Colors.grey[300],
            backgroundImage: AssetImage("assets/images/trader_profile.jpg"),
            onBackgroundImageError: (_, __) {
              Icon(Icons.person, color: Colors.grey[600], size: 20.r);
            },
          ),
          SizedBox(width: 12.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text("Alex Sen", style: TextStyle(fontSize: 15.sp, fontWeight: FontWeight.w600)),
                Text("\$2500 invested", style: TextStyle(fontSize: 12.sp, color: Colors.grey)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text("+1,200 (+10.3%)", style: TextStyle(fontSize: 12.sp, color: Colors.green)),
              Text("+\$2847", style: TextStyle(fontSize: 14.sp, fontWeight: FontWeight.bold)),
            ],
          )
        ],
      ),
    );
  }
}
