import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


class FilterScreen extends StatefulWidget {
  const FilterScreen({super.key});

  @override
  State<FilterScreen> createState() => _FilterScreenState();
}

class _FilterScreenState extends State<FilterScreen> {
  int selectedTraderType = 0;
  double returnOnInvestment = 25;
  double winRate = 37;
  int selectedRiskLevel = 1;
  int selectedDowntime = 1;

  final primaryColor = Color(0xFF0B5638);
  final primaryfont = TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w500, color: Colors.black, fontFamily: 'Poppins');
  final secondaryfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, color: Colors.black, fontFamily: 'Arial');

  final List<String> traderTypes = ['Forex', 'Commodities', 'Stock', 'Future'];
  final List<String> riskLevels = ['Low', 'Medium', 'High'];
  final List<String> downtimes = ['1month', '3month', '6 month', '1 year'];

  void clearFilters() {
    setState(() {
      selectedTraderType = 0;
      returnOnInvestment = 0;
      winRate = 0;
      selectedRiskLevel = 1;
      selectedDowntime = 1;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          backgroundColor: Colors.white,
          elevation: 0,
          leading: IconButton(
            icon: Icon(Icons.close, color: Colors.black),
            onPressed: () => Navigator.pushNamed(context, '/search_trader'),
          ),
          title: Text(
            'Filter',
            style: primaryfont.copyWith(fontSize: 18.sp),
          ),
          centerTitle: true,
        ),
        body: LayoutBuilder(
          builder: (context, constraints) {
            return SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 10.h),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: constraints.maxHeight,
                ),
                child: IntrinsicHeight(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLabel('Trader Type'),
                      Wrap(
                        spacing: 10.w,
                        children: List.generate(traderTypes.length, (index) {
                          return ChoiceChip(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.r),
                            ),
                            label: Text(traderTypes[index],),
                            selected: selectedTraderType == index,
                            onSelected: (_) {
                              setState(() => selectedTraderType = index);
                            },
                            selectedColor: primaryColor,
                            backgroundColor: Colors.white,
                            labelStyle: secondaryfont.copyWith(
                              color: selectedTraderType == index ? Colors.white : Colors.black,
                            ),
                          );
                        }),
                      ),
                      SizedBox(height: 20.h),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _buildLabel('Return of Investment'),
                          Text("0% - ${returnOnInvestment.round()}%", 
                            style: secondaryfont.copyWith(fontWeight: FontWeight.w500)),
                        ],
                      ),
                      Slider(
                        value: returnOnInvestment,
                        min: 0,
                        max: 100,
                        activeColor: primaryColor,
                        onChanged: (value) => setState(() => returnOnInvestment = value),
                      ),
                      SizedBox(height: 10.h),

                      _buildLabel('Risk Level'),
                      Container(
                        width: double.infinity,
                        height: 35.h,
                        padding: EdgeInsets.all(3.r),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(color: Colors.grey[300]!),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: List.generate(riskLevels.length, (index) {
                            return Expanded(
                              child: Padding(
                                padding: EdgeInsets.symmetric(horizontal: 2.w),
                                child: ElevatedButton(
                                  onPressed: () => setState(() => selectedRiskLevel = index),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor:
                                    selectedRiskLevel == index ? primaryColor : Colors.white,
                                    foregroundColor:
                                    selectedRiskLevel == index ? Colors.white : Colors.black,
                                    side: BorderSide(color: Colors.grey),
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(6.r),
                                    ),
                                  ),
                                  child: Text(riskLevels[index], style: secondaryfont.copyWith(
                                    color: selectedRiskLevel == index ? Colors.white : Colors.black,
                                  )),
                                ),
                              ),
                            );
                          }),
                        ),
                      ),
                      SizedBox(height: 20.h),

                      _buildLabel('Downtime'),
                      Wrap(
                        spacing: 8.w,
                        runSpacing: 8.h,
                        children: List.generate(downtimes.length, (index) {
                          return ChoiceChip(
                            label: Text(downtimes[index]),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20.r),
                            ),
                            selected: selectedDowntime == index,
                            onSelected: (_) => setState(() => selectedDowntime = index),
                            selectedColor: primaryColor,
                            backgroundColor: Colors.white,
                            labelStyle: secondaryfont.copyWith(
                              color: selectedDowntime == index ? Colors.white : Colors.black,
                            ),
                          );
                        }),
                      ),
                      SizedBox(height: 20.h),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                           _buildLabel('Win Rate'),
                           Text("0% - ${winRate.round()}%", 
                            style: secondaryfont.copyWith(fontWeight: FontWeight.w500)),
                        ],
                      ),
                      Slider(
                        value: winRate,
                        min: 0,
                        max: 100,
                        activeColor: primaryColor,
                        onChanged: (value) => setState(() => winRate = value),
                      ),
                      SizedBox(height: 50.h),

                      Row(
                        children: [
                          Expanded(
                            child: OutlinedButton(
                              onPressed: (){
                                clearFilters();
                              },
                              style: OutlinedButton.styleFrom(
                                side: BorderSide(color: Color(0xff217252)),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.r),
                                ),
                                padding: EdgeInsets.symmetric(vertical: 14.h),
                              ),
                              child: Text('Clear', style: primaryfont.copyWith(color: Color(0xff217252))),
                            ),
                          ),
                          SizedBox(width: 12.w),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: () {
                                // Apply filters and navigate back
                                Navigator.pop(context, {
                                  'traderType': selectedTraderType,
                                  'returnOnInvestment': returnOnInvestment,
                                  'winRate': winRate,
                                  'riskLevel': selectedRiskLevel,
                                  'downtime': selectedDowntime,
                                });
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: primaryColor,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30.r),
                                ),
                                padding: EdgeInsets.symmetric(vertical: 14.h),
                              ),
                              child: Text('Apply', style: primaryfont.copyWith(color: Colors.white)),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
            );
          },
        ),
      
    );
  }

  Widget _buildLabel(String text) {
    return Padding(
      padding: EdgeInsets.only(bottom: 8.h, top: 12.h),
      child: Text(
        text,
        style: primaryfont.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }
}
