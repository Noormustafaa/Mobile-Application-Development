import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:copy_trader_app/HomeScreens/transactionPopUp.dart';

class WithdrawTransactionsScreen extends StatefulWidget {
  final bool? initialIsDeposit; // Optional parameter to set initial tab
  const WithdrawTransactionsScreen({super.key, this.initialIsDeposit});

  @override
  State<WithdrawTransactionsScreen> createState() => _WithdrawTransactionsScreen();
}

class _WithdrawTransactionsScreen extends State<WithdrawTransactionsScreen> {
  final titlefont = TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w600, fontFamily: 'Poppins', color: Colors.black);
  bool isDeposit = false; // false = withdraw, true = deposit

  @override
  void initState() {
    super.initState();
    // Set initial tab based on parameter, default to withdraw
    isDeposit = widget.initialIsDeposit ?? false;
  }

  
   int _selectedIndex = 3;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
       appBar: AppBar(
            leading:  IconButton(
              icon: Icon(Icons.arrow_back),
              onPressed: () {
                Navigator.pushNamed(context, '/wallet');
              },
              ),
            title: Text('All Transactions', style: titlefont),
            centerTitle: true,
            backgroundColor: Colors.white,
            foregroundColor: Colors.black,
            elevation: 0,
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                height: 45.h,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(32.r),
                  boxShadow: [
                    BoxShadow(
                      color: Color(0xffE4E2E2),
                      spreadRadius: 1,
                      blurRadius: 3,
                    ),
                  ],
                ),
                child: Row(
                  children: [
                    // Deposit Tab
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            isDeposit = true;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: isDeposit ? Color(0xff0B5638) : Colors.transparent,
                            borderRadius: BorderRadius.circular(32.r),
                          ),
                          child: Center(
                            child: Text(
                              "Deposit",
                              style: TextStyle(
                                color: isDeposit ? Colors.white : Colors.black,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                    // Withdraw Tab
                    Expanded(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            isDeposit = false;
                          });
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            color: !isDeposit ? Color(0xff0B5638) : Colors.transparent,
                            borderRadius: BorderRadius.circular(32.r),
                          ),
                          child: Center(
                            child: Text(
                              "Withdraw",
                              style: TextStyle(
                                color: !isDeposit ? Colors.white : Colors.black,
                                fontSize: 16.sp,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20.h),
              Expanded(
                child: ListView.builder(
                  itemCount: 6,
                  itemBuilder: (context, index) {
                    return GestureDetector(
                      onTap: () {
                        _showTransactionSummary(context, index);
                      },
                      child: Container(
                        margin: EdgeInsets.only(bottom: 12.h),
                        padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 12.h),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(12.r),
                          border: Border.all(color: Colors.grey.shade300),
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey.withOpacity(0.05),
                              spreadRadius: 1,
                              blurRadius: 3,
                            ),
                          ],
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: EdgeInsets.all(10.r),
                              decoration: BoxDecoration(
                                color: isDeposit 
                                  ? Colors.green.withOpacity(0.1) 
                                  : Colors.red.withOpacity(0.1),
                                borderRadius: BorderRadius.circular(8.r),
                              ),
                              child: Icon(
                                isDeposit ? FontAwesomeIcons.download : FontAwesomeIcons.upload,
                                color: isDeposit ? Colors.green : Colors.red,
                                size: 24.sp,
                              ),
                            ),
                            SizedBox(width: 12.w),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    isDeposit ? "Cash Deposit" : "Cash Withdraw",
                                    style: TextStyle(
                                      fontSize: 14.sp,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: 'Poppins',
                                      color: Colors.black,
                                    ),
                                  ),
                                  SizedBox(height: 4.h),
                                  Text(
                                    "12/6/2025   3445262",
                                    style: TextStyle(
                                      color: Colors.grey.shade600,
                                      fontSize: 12.sp,
                                    ),
                                  )
                                ],
                              ),
                            ),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                Text(
                                  isDeposit ? "+\$500" : "-\$500",
                                  style: TextStyle(
                                    color: isDeposit ? Colors.green : Colors.red,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 16.sp,
                                    fontFamily: 'Poppins',
                                  ),
                                ),
                                
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              )
            ],
          ),
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        selectedIndex: _selectedIndex,
        onItemTapped: _onNavItemTapped,
      ),
    );
  }

  void _showTransactionSummary(BuildContext context, int index) {
    // Get the transaction data based on current tab and index
    final transactionType = isDeposit ? "Cash Deposit" : "Cash Withdraw";
    final amount = isDeposit ? "+\$500" : "-\$500";
    final processingFee = isDeposit ? "Free" : "\$2.50";
    
    // Create transaction data map to pass to the popup screen
    final transactionData = {
      "Transaction ID": "3445262",
      "Category": transactionType,
      "Amount": amount,
      "Date": "12/6/2025",
      "Payment Method": "Bank Transfer",
      "Status": "Completed",
      "Processing Fee": processingFee,
    };
    
    // Navigate to existing transaction popup screen
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => TransactionSummaryScreen(
          transactionData: transactionData,
        ),
      ),
    );
  }
}
