import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/sharedFile.dart';


class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key});

  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen> {
  String? selectedRole;

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = const Color(0xFF185C3C);

    return Scaffold(
      backgroundColor: Colors.white,
    
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.symmetric(horizontal: 28.w, vertical: 16.h),
              child: Column(
                children: [
                  SizedBox(height: 35.h),

                  // Top Turtle Icon
                  Image.asset(
                    'assets/images/turtle_icon.png',
                    height: 72.h,
                    width: 73.w,
                  ),
                  SizedBox(height: 18.h),

                  Text(
                    '1/3 How would you like to use Copy Traders ?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 22.sp,
                      fontFamily: 'Poppins',
                    ),
                  ),
                  SizedBox(height: 30.h),

                  /// Trader Option (with built-in Icon)
                  RoleOptionTile(
                    icon: const Icon(Icons.person_outline, size: 28),
                    title: 'Trader',
                    subtitle: 'Manage trades and strategies',
                    value: 'trader',
                    selectedValue: selectedRole,
                    onSelected: (val) {
                      setState(() {
                        selectedRole = val;
                        SharedData.selectedRole = selectedRole;
                      });
                    },
                  ),

                  SizedBox(height: 16.h),

                  /// Investor Option (with image instead of icon)
                  RoleOptionTile(
                    icon: Image.asset(
                      'assets/images/money_bag.png',
                      height: 30.h,
                      width: 30.w,
                    ),
                    title: 'Investor',
                    subtitle: 'Invest and copy skilled traders',
                    value: 'investor',
                    selectedValue: selectedRole,
                    onSelected: (val) {
                      setState(() {
                        selectedRole = val;
                        SharedData.selectedRole = selectedRole;
                      });
                    },
                  ),
                  SizedBox(height: 30.h),

                  /// Continue Button
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (selectedRole != null) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('Selected: $selectedRole')),
                          );
                          Navigator.pushNamed(context, '/verify');
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                                content: Text('Please select a role')),
                          );
                        }
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: primaryColor,
                        padding: EdgeInsets.symmetric(
                            horizontal: 40.w, vertical: 12.h),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.r),
                        ),
                        minimumSize: Size(double.infinity, 52.h),
                      ),
                      child: Text(
                        'Continue',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 22.sp,
                          fontWeight: FontWeight.w600,
                          fontFamily: 'Poppins',
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

//
// Custom RoleOptionTile Widget
//
class RoleOptionTile extends StatelessWidget {
  final Widget icon;
  final String title;
  final String subtitle;
  final String value;
  final String? selectedValue;
  final ValueChanged<String> onSelected;

  const RoleOptionTile({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.value,
    required this.selectedValue,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final bool isSelected = selectedValue == value;

    return GestureDetector(
      onTap: () => onSelected(value),
      child: Container(
        width: double.infinity,
        padding: EdgeInsets.symmetric(vertical: 10.h, horizontal: 16.w),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFF0F7F4) : Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isSelected ? const Color(0xFF1E6C50) : Colors.grey.shade300,
            width: 1.5.w,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                icon,
                SizedBox(width: 6.w),
                Text(
                  title,
                  style: TextStyle(
                    fontWeight: FontWeight.w400,
                    fontSize: 20.sp,
                    fontFamily: 'Arial',
                  ),
                ),
              ],
            ),
            SizedBox(height: 5.h),
            Text(
              subtitle,
              //textAlign: TextAlign.center,
              style: TextStyle(color: Colors.grey.shade600, fontSize: 15.sp, fontFamily: 'Arial', fontWeight: FontWeight.w400),
            ),
          ],
        ),
      ),
    );
  }
}


