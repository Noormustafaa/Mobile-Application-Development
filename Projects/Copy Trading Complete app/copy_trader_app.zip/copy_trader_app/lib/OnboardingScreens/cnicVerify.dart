import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/sharedFile.dart';

class Cnicverifyscreen extends StatefulWidget {
  const Cnicverifyscreen({super.key});

  @override
  State<Cnicverifyscreen> createState() => _CnicverifyscreenState();
}

class _CnicverifyscreenState extends State<Cnicverifyscreen> {
  String ? selected = SharedData.selectedRole;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 28.w, vertical: 20.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                SizedBox(height: 30.h),

               //Top Turtle Icon
                Image.asset(
                  'assets/images/turtle_icon.png',
                  height: 60.h,
                  width: 61.w,
                ),


              SizedBox(height: 16.h),

              // Heading
              Text(
                '2/3 Verify your Identity',
                style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w600, fontFamily: 'Poppins'),
              ),

              SizedBox(height: 24.h),

              // Upload CNIC Front
              Align(
                alignment: Alignment.center,
                child: Text('Upload Your CNIC Front', style: TextStyle(fontWeight: FontWeight.w400, fontFamily: 'SFProDisplay,', fontSize: 14.sp )),
              ),

              SizedBox(height: 8.h),
              
              _buildUploadBox(),

              SizedBox(height: 24.h),

              // Upload CNIC Back
              Align(
                alignment: Alignment.center,
                child: Text('Upload Your CNIC Back', style: TextStyle(fontWeight: FontWeight.w400, fontFamily: 'SFProDisplay,', fontSize: 14.sp)),
              ),

              SizedBox(height: 8.h),
              
              _buildUploadBox(),

              SizedBox(height: 50.h),

              // Privacy note
              Text(
                'Your data is encrypted and securely processed in accordance with KYC laws.',
                textAlign: TextAlign.center,
                style: TextStyle(color: Color(0xFF706D6D),
                  fontSize: 10.sp,
                  fontFamily: 'Arial',
                  fontWeight: FontWeight.w400,),
              ),

              SizedBox(height: 20.h),

              // Continue button
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    //  Add file check or validation here

                    // After Validation, navigate to the next screen
                    if (selected == 'trader') {
                      Navigator.pushNamed(context, '/trader_screen');
                    } else if (selected == 'investor') {
                      Navigator.pushNamed(context, '/investor_screen');
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF004D32),
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                    elevation: 4,
                  minimumSize: Size(double.infinity, 50.h), 
                  ),
                  child: Text('Continue', style: TextStyle(fontWeight: FontWeight.w600, color: Colors.white, fontSize: 18.sp, fontFamily: 'Poppins',)),
                ),
              ),

              SizedBox(height: 20.h),
            ],
          ),
        ),
      ),
    ));
  }

  Widget _buildUploadBox() {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton(
        onPressed: () {
          // Handle file upload
        },
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        side: BorderSide(color: Colors.white,  width: 2.w),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.r),
        ),
        padding: EdgeInsets.symmetric(vertical: 20.h),
        elevation: 4,
      ),
      child: Column(
        children: [
          Icon(
            FontAwesomeIcons.filePdf,
            size: 35,
            color: Color(0xFF185C3C),
          ),
          SizedBox(height: 8.h),
          Text.rich(
            TextSpan(
              children: [
                TextSpan(text: 'Drop your file(s) here, or ', style: TextStyle(color: Colors.black, fontSize: 12.sp, fontWeight: FontWeight.w500, fontFamily: 'Inter_28pt')),
                TextSpan(text: 'Browse', style: TextStyle(color: Color(0xFF0C756F), fontSize: 12.sp, fontWeight: FontWeight.w500, fontFamily: 'Inter_28pt')),
              ],
            ),
            textAlign: TextAlign.center,
          ),
          SizedBox(height: 4.h),
          Text('Supports: pdf, Max file size 20MB', style: TextStyle(fontSize: 9.sp, color: Colors.grey, fontWeight: FontWeight.w500, fontFamily: 'Inter_28pt')),
        ],
      ),
    ));
  }
}