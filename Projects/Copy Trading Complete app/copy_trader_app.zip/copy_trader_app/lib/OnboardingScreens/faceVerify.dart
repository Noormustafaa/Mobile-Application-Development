import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/sharedFile.dart';

class FaceVerification extends StatefulWidget {
  const FaceVerification({super.key});

  @override
  State<FaceVerification> createState() => _FaceVerificationScreen();

}

class _FaceVerificationScreen extends State<FaceVerification> {
  String? selected = SharedData.selectedRole;
  bool isScanning = false;

  void startScan() async{
    setState(() {
      isScanning = true;
    });

    
    // Simulate a face scan process
    // In a real application, you would integrate with a face scanning library
    // or API to perform the actual scan.
    await Future.delayed(Duration(seconds: 3),);

    //After scan is complete, navigate to the next screen

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Face scan successfully!'),
      ),
    );

    if (selected == 'trader') {
      // Navigate to trader screen
      Navigator.pushNamed(context, '/trader_screen');
    } else if (selected == 'investor') {
      // Navigate to investor screen
      Navigator.pushNamed(context, '/investor_screen');
    }
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 28.w, vertical: 16.h),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 20.h),

                //Top Turtle Icon
                Image.asset(
                'assets/images/turtle_icon.png',
                height: 72.h,
                width: 73.w,
              ),

              SizedBox(height: 18.h),

                // Progress Title
                Text(
                  '2/3 Verify your Identity',
                  style: TextStyle( 
                    fontWeight: FontWeight.w600,
                    fontSize: 20.sp,
                    fontFamily: 'Poppins',

                  ),
                ),
              SizedBox(height: 20.h),

                // Subtitle
                Text(
                  'Scan your face to verify your identity',
                  style: TextStyle(fontSize: 14.sp, color: Colors.black87, fontFamily:'AlbertSans', fontWeight: FontWeight.w400),
                  textAlign: TextAlign.center,
                ),
              SizedBox(height: 32.h),

                // Face scan placeholder box
                Container(
                  width: 250.w,
                  height: 200.h,
                  decoration: BoxDecoration(
                    border: Border.all(color: Color(0xff239869), width: 2.w),
                    borderRadius: BorderRadius.circular(4.r),
                  ),
                  child: Image.asset(
                    'assets/images/face_id.png',
                    )
                  ),
                
              SizedBox(height: 8.h),

                // Bottom hint text
                Text(
                  "We'll automatically detect your face",
                  style: TextStyle(fontSize: 12.sp, color: Colors.black54, fontFamily: 'Arial', fontWeight: FontWeight.w400 ),
                ),
              SizedBox(height: 30.h),

                // Start Scanning Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: isScanning ? null : startScan,

                   // Disable button while scanning
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color(0xFF004D40),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.r),
                    ), 
                     minimumSize: Size(double.infinity, 52.h),
                     elevation: 4,
                  ),
                  
                  child: Text(
                    'Start Scanning',
                    style: TextStyle(
                      fontWeight: FontWeight.w600, color: Colors.white,
                      fontSize: 22.sp, fontFamily: 'Poppins',
                    ),
                  ),
                ),),

              ],
            ),
          ),
        ),
      ),
    );
  }
}
