import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';



class InvestorScreen extends StatefulWidget {
  const InvestorScreen({super.key});

  @override
  State<InvestorScreen> createState() => _InvestorScreenState();

}

class _InvestorScreenState extends State<InvestorScreen> {
  String selectedRisk = '';
  List<String> traderFocusOptions = ['Forex', 'Commodities', 'Futures', 'CFDs'];
  Set<String> selectedFocus = {'CFDs'};

  String selectedTimeline = '0-3 month';
  List<String> timelineOptions = ['0-3 month', '3-12 month', '12+ month'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 28.w, vertical: 20.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 40.h),
                
                // Center the top section
                Center(
                  child: Column(
                    children: [
                      //Top Turtle Icon
                      Image.asset(
                        'assets/images/turtle_icon.png',
                        height: 72.h,
                        width: 73.w,
                      ),
                      SizedBox(height: 16.h),
                      // Title
                      Text(
                        "3/3 Set Your Investment Preferences",
                        style: TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w600, fontFamily: 'Poppins'),
                        textAlign: TextAlign.center,
                      ),
                    ],
                  ),
                ),
                
                SizedBox(height: 30.h),

                // Risk Preferences
                Text('1. Risk Preferences', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),

                Row(
                  children: ['Low', 'Medium', 'High'].map((risk) {
                    return Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                            Radio(
                            value: risk,
                            groupValue: selectedRisk,
                            onChanged: (value) {
                              setState(() => selectedRisk = value.toString());
                            },
                            activeColor: Color(0xFF0B5638),
                          ),
                            ],
                          ),
                         Row(
                          children: [
                            SizedBox(width: 10.w),
                            Text(
                              risk, 
                              style: TextStyle(fontSize: 14.sp, fontFamily: 'Montserrat', fontWeight: FontWeight.w400)
                            ),
                          ],
                         )
                         
                        ],
                      ),
                    );
                  }).toList(),
                ),

                SizedBox(height: 20.h),

                // Trader Focus
                Text('2. Trader Focus', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),

                Wrap(
                  spacing: 15.w,     //horizontal spacing between checkboxes
                  runSpacing: 8.h,  //vertical spacing between rows
                  children: traderFocusOptions.map((focus) {
                    return Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Checkbox(
                          value: selectedFocus.contains(focus),
                          onChanged: (bool? value) {
                            setState(() {
                              if (value == true) {
                                selectedFocus.add(focus);
                              } else {
                                selectedFocus.remove(focus);
                              }
                            });
                          },
                          activeColor: Color(0xFF0B5638),
                        ),
                        Text(focus, style: TextStyle(fontSize: 14.sp, fontFamily: 'Montserrat', fontWeight: FontWeight.w400)),
                      ],
                    );
                  }).toList(),
                ),

                SizedBox(height: 20.h),

                // Investment Timeline
                Text('3. Investment Timeline', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: timelineOptions.map((timeline) {
                    final isSelected = selectedTimeline == timeline;
                    return Expanded(
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 5.w),
                        child: GestureDetector(
                          onTap: () => setState(() => selectedTimeline = timeline),
                          child: Container(
                            padding: EdgeInsets.symmetric(vertical: 10.h),
                            decoration: BoxDecoration(
                              color: isSelected ? Color(0xFF047C4C) : Colors.transparent,
                              border: Border.all(color: Color(0xFFD1D1D6), width: 1.5.w),
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                            child: Center(
                              child: Text(
                                timeline,
                                style: TextStyle(
                                  color: isSelected ? Colors.white : Colors.black, 
                                  fontSize: 13.sp, fontFamily: 'Montserrat', fontWeight: FontWeight.w400
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),

                SizedBox(height: 40.h),

                // Submit Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF004D40),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r),
                      ),
                      elevation: 4,
                      minimumSize: Size(double.infinity, 50.h),
                    ),
                    onPressed: () {
                      // Handle form submission
                    },
                    child: Text('Continue', style: TextStyle(fontWeight: FontWeight.w600, 
                                           color: Colors.white, fontSize: 18.sp, fontFamily: 'Poppins',)),
                  ),
                ),

                SizedBox(height: 20.h),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
