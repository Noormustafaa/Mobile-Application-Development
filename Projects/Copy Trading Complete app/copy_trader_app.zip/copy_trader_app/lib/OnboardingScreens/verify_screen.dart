import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


class VerifyIdentityScreen extends StatefulWidget {
  const VerifyIdentityScreen({super.key});

  @override
  State<VerifyIdentityScreen> createState() => _VerifyIdentityScreenState();
}

class _VerifyIdentityScreenState extends State<VerifyIdentityScreen> {
  String? selectedOption;

  final Color primaryColor = const Color(0xFF185C3C);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 28.w, vertical: 16.h),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minHeight: MediaQuery.of(context).size.height - MediaQuery.of(context).padding.top - 32.h,
            ),
            child: Column(
                  children: [
                    SizedBox(height: 40.h),

                    // Top Turtle Icon
                    Image.asset(
                      'assets/images/turtle_icon.png',
                      height: 72.h,
                      width: 73.w,
                    ),

                    SizedBox(height: 28.h),

                    // Title
                    Text(
                      '2/3 Verify your Identity',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontWeight: FontWeight.w600,
                        fontSize: 20.sp,
                        fontFamily: 'Poppins',
                      ),
                    ),
                    SizedBox(height: 12.h),

                    // Subtitle
                    Text(
                      'To access all features, please complete your identity verification.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF666C69),
                        fontSize: 14.sp,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(height: 32.h),

                    // Face ID Option
                    _buildOptionTile(
                      icon: FontAwesomeIcons.faceSmile,
                      label: 'Face ID Verification',
                      value: 'face',
                      selectedValue: selectedOption,
                      onSelected: (val) => setState(() => selectedOption = val),
                    ),
                    SizedBox(height: 16.h),

                    // CNIC Option
                    _buildOptionTile(
                      icon: FontAwesomeIcons.idCard,
                      label: 'CNIC Verification',
                      value: 'cnic',
                      selectedValue: selectedOption,
                      onSelected: (val) => setState(() => selectedOption = val),
                    ),

                    SizedBox(height: 60.h),

                    // Footer Text
                    Text(
                      'Your data is encrypted and securely processed in accordance with KYC laws.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Color(0xFF706D6D),
                        fontSize: 10.sp,
                        fontFamily: 'Arial',
                        fontWeight: FontWeight.w400,
                      ),
                    ),
                    SizedBox(height: 16.h),

                    // Continue Button
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed:(){
                          if (selectedOption != null) {
                            if (selectedOption == 'face') {
                              Navigator.pushNamed(context, '/face_verify');
                            } else if (selectedOption == 'cnic') {
                              Navigator.pushNamed(context, '/cnic_verify');
                            }
                          } else {
                            //show the message if no option is selected
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Please select a verification method'),
                              ),
                            );
                          }
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: primaryColor,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12.r),
                          ),
                          elevation: 4,
                          minimumSize: Size(double.infinity, 52.h),
                        ),
                        child: Text(
                          'Continue',
                          style: TextStyle(
                              color: Colors.white, fontSize: 22.sp, fontWeight: FontWeight.w600,fontFamily: 'Poppins',),
                        ),
                      ),
                    ),
                    SizedBox(height: 20.h),
                  ],
                ),
              ),
            ),
          ),
        );
  }


// Custom buildOptionTile widget
  Widget _buildOptionTile({
    required IconData icon,
    required String label,
    required String value,
    required String? selectedValue,
    required ValueChanged<String> onSelected,
  }) {
    final bool isSelected = selectedValue == value;

    return GestureDetector(
      onTap: () => onSelected(value),      
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 12.w),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFFF0F7F4) : Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(
            color: isSelected ? const Color(0xFF1E6C50) : Colors.grey.shade300,
            width: 1.5.w,
          ),
        ),
        child: Row(
          children: [
            Icon(icon, size: 28, color: Colors.black87),
            SizedBox(width: 16.w),
            Text(
              label,
              style: TextStyle(
                fontSize: 16.sp,
                fontWeight: FontWeight.w500,
                fontFamily: 'Poppins',
                color: Color(0xFF000000),
              ),
            )
          ],
        ),
      ),
    );
  }
}