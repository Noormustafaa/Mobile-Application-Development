import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TradingStyleScreen extends StatefulWidget {
  const TradingStyleScreen({super.key});

  @override
  State<TradingStyleScreen> createState() => _TradingStyleScreenState();
}

class _TradingStyleScreenState extends State<TradingStyleScreen> {
  String selectedAsset = 'Forex';
  String selectedTrading = 'Scalper';
  String selectedCapital = 'propfirm';

  List<String> assetClasses = ['Forex', 'Stocks', 'Crypto'];
  List<String> tradingStyles = ['Scalper', 'Day Trader', 'Swing Trader'];
  List<String> capitalTypes = ['propfirm', 'client capital', 'own capital', 'other'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.all(20.r),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Column(
                    children: [
                      SizedBox(height: 60.h),

                      // Top Turtle Icon
                      Image.asset(
                        'assets/images/turtle_icon.png',
                        height: 72.h,
                        width: 73.w,
                      ),

                      SizedBox(height: 18.h),
                      Text("3/3 Tell us about your Trading style",
                          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 21.sp, fontFamily: 'Poppins',)),
                    ],
                  ),
                ),

                SizedBox(height: 30.h),

                TextField(
                  decoration: InputDecoration(
                    hintText: '1. Briefly Describe your trading Approach',
                    hintStyle: TextStyle(fontSize: 16.sp, color: Color(0xffBEBCBC), fontWeight: FontWeight.w400, fontFamily: 'Montserrat',),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
                    filled: true,
                    fillColor: Colors.grey[100],
                  ),
                  maxLines: 2,
                ),

                SizedBox(height: 20.h),
            
                Text('2. Trading Name', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),

                TextField(
                  decoration: InputDecoration(
                    hintText: 'Abc h',
                    hintStyle: TextStyle(fontSize: 16.sp, color: Color(0xffBEBCBC), fontWeight: FontWeight.w400, fontFamily: 'Montserrat',),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                ),

                SizedBox(height: 20.h),

                Text('3. Select Asset Classes', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),
                
                DropdownButtonFormField(
                  value: selectedAsset,
                  items: assetClasses
                      .map((asset) => DropdownMenuItem(value: asset, child: Text(asset, style: TextStyle(fontSize: 14.sp, fontFamily: 'Montserrat', fontWeight: FontWeight.w400))))
                      .toList(),
                  onChanged: (value) => setState(() => selectedAsset = value.toString()),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
                  ),
                ),

                SizedBox(height: 20.h),

                Text('4. Choose Your Trading Style', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),

                Row(
                  children: tradingStyles.map((style) {
                    return Expanded(
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              Radio(
                            value: style,
                            groupValue: selectedTrading,
                            onChanged: (value) => setState(() => selectedTrading = value.toString()),
                            activeColor: Colors.teal[800],
                          ),
                            ],
                          ),
                          Row(
                            children: [
                              Text(
                              style, 
                              style: TextStyle(fontSize: 13.sp, fontFamily: 'Acme', fontWeight: FontWeight.w400),
                              overflow: TextOverflow.ellipsis,
                            ),
                            ],
                          )
                        ],
                      ),
                    );
                  }).toList(),
                ),
                SizedBox(height: 20.h),
                
                Text('5. What do you currently Trade', style: TextStyle(fontWeight: FontWeight.w500, fontFamily: 'Poppins', fontSize: 18.sp)),

                SizedBox(height: 10.h),

                DropdownButtonFormField(
                  value: selectedCapital,
                  items: capitalTypes
                      .map((type) => DropdownMenuItem(value: type, child: Text(type, style: TextStyle(fontSize: 14.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w300))))
                      .toList(),
                  onChanged: (value) => setState(() => selectedCapital = value.toString()),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(10.r)),
                  ),
                ),

                SizedBox(height: 30.h),

                // Submit Button
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF185C3C),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.r)),
                        elevation: 4,
                        minimumSize: Size(double.infinity, 52.h),
                     ),
                    onPressed: () {
                      Navigator.pushReplacementNamed(context, '/home');
                    },
                    child: Text('Submit', style: TextStyle(color: Colors.white, fontSize: 22.sp, fontWeight: FontWeight.w600,fontFamily: 'Poppins',),),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
