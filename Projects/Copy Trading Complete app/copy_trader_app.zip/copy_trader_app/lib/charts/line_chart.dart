// File: /lib/charts/trader_line_chart.dart
import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class TraderLineChart extends StatelessWidget {
  final List<FlSpot> spots;
  final Color lineColor;
  final double barWidth;

  const TraderLineChart({
    super.key,
    required this.spots,
    this.lineColor = const Color(0xFF12EB07),
    this.barWidth = 3
  });

  // Month labels for X-axis
  static const List<String> monthLabels = [
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];

  // Helper method to get month label
  String getMonthLabel(double value) {
    int index = value.toInt();
    if (index >= 0 && index < monthLabels.length) {
      return monthLabels[index];
    }
    return '';
  }

  // Helper method to calculate appropriate Y-axis interval
  double getYAxisInterval() {
    if (spots.isEmpty) return 50;
    
    double maxY = spots.map((e) => e.y).reduce((a, b) => a > b ? a : b);
    
    if (maxY >= 100000) {
      return 50000; // 50K intervals for large numbers
    } else if (maxY >= 10000) {
      return 10000; // 10K intervals
    } else if (maxY >= 1000) {
      return 1000; // 1K intervals
    } else {
      return 100; // 100 intervals for small numbers
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 270.w,
      height: 160.h, // Increased height to accommodate axis labels
      child: LineChart(
        LineChartData(
          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
            horizontalInterval: getYAxisInterval(), // Dynamic interval
            getDrawingHorizontalLine: (value) {
              return FlLine(
                color: Colors.grey.withOpacity(0.2), // More subtle grid lines
                strokeWidth: 0.5, // Thinner lines
              );
            },
          ),
          borderData: FlBorderData(
            show: true,
            border: Border(
              bottom: BorderSide(color: Colors.grey.withOpacity(0.5), width: 1),
              left: BorderSide(color: Colors.grey.withOpacity(0.5), width: 1),
            ),
          ),
          titlesData: FlTitlesData(
            show: true,
            rightTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            topTitles: AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30.h,
                interval: 1,
                getTitlesWidget: (double value, TitleMeta meta) {
                  return Text(
                    getMonthLabel(value),
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w400,
                      fontSize: 8.sp,
                    ),
                  );
                },
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 45.w,
                interval: getYAxisInterval(), // Dynamic interval
                getTitlesWidget: (double value, TitleMeta meta) {
                  // Format large numbers better
                  String label;
                  if (value >= 1000000) {
                    label = '${(value / 1000000).toStringAsFixed(1)}M';
                  } else if (value >= 1000) {
                    label = '${(value / 1000).toStringAsFixed(0)}K';
                  } else {
                    label = '${value.toInt()}';
                  }
                  
                  return Text(
                    label,
                    style: TextStyle(
                      color: Colors.grey[600],
                      fontWeight: FontWeight.w400,
                      fontSize: 8.sp,
                    ),
                  );
                },
              ),
            ),
          ),
          minX: 0,
          maxX: (spots.isNotEmpty) ? spots.map((e) => e.x).reduce((a, b) => a > b ? a : b) : 11,
          minY: 0,
          maxY: (spots.isNotEmpty) ? spots.map((e) => e.y).reduce((a, b) => a > b ? a : b) + 50 : 300,
          lineBarsData: [
            LineChartBarData(
              spots: spots,
              isCurved: true,
              color: lineColor,
              barWidth: barWidth,
              belowBarData: BarAreaData(
                show: false, // Remove the green filled area below the line
              ),
              dotData: FlDotData(
                show: true,
                getDotPainter: (spot, percent, barData, index) {
                  return FlDotCirclePainter(
                    radius: 3,
                    color: lineColor,
                    strokeWidth: 2,
                    strokeColor: Colors.white,
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
