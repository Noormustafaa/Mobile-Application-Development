import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class CustomPieChart extends StatelessWidget {
  final List<Map<String, dynamic>> data;

  const CustomPieChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        // Pie Chart
        SizedBox(
          height: 200.h,
          child: PieChart(
            PieChartData(
              sections: data.map((item) {
                return PieChartSectionData(
                  value: item['value'],
                  color: item['color'],
                  title: '${item['title']} ${item['value']}%',
                  radius: 70.r,
                  titleStyle: TextStyle(fontSize: 8.sp, fontWeight: FontWeight.w400,fontFamily: 'Inter', color: Colors.white),
                );
              }).toList(),
              
            ),
          ),
        ),

        SizedBox(height: 20.h),

        // Legend
        Wrap(
          spacing: 20.w,
          runSpacing: 10.h,
          children: data.map((item) {
            return Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 14.r, height: 14.r, color: item['color'],),
                SizedBox(width: 6.w),
                Text('${item['title']}'),
              ],
            );
          }).toList(),
        )
      ],
    );
  }
}