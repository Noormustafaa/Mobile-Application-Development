import 'package:flutter/material.dart';

//routes import

// SignUp Screens
import 'SignUpScreens/splash_screen.dart';
import 'SignUpScreens/login_page.dart';
import 'SignUpScreens/sign_up.dart';

// Onboarding Screens
import 'OnboardingScreens/role_selection.dart';
import 'OnboardingScreens/verify_screen.dart';
import 'OnboardingScreens/faceVerify.dart';
import 'OnboardingScreens/cnicVerify.dart';
import 'OnboardingScreens/investorScreen.dart';
import 'OnboardingScreens/traderScreen.dart';

//Settings Screens
import 'SettingScreens/profileSettingScreen.dart';
import 'SettingScreens/editProfileScreen.dart';
import 'SettingScreens/paymentMethodScreen.dart';
import 'SettingScreens/addCardScreen.dart';

//Trader Dashboard Screens
import 'TraderDashboardScreens/traderDashboardEquity.dart';
import 'TraderDashboardScreens/traderDashboardProfile.dart';
import 'TraderDashboardScreens/traderDashboardMetrices.dart';
import 'TraderDashboardScreens/traderDashboardProfit.dart';

// Home Screens
import 'HomeScreens/homeScreen.dart';
import 'HomeScreens/searchTrader.dart';
import 'HomeScreens/filterScreen.dart';
import 'HomeScreens/investScreen.dart';
import 'HomeScreens/walletScreen.dart';
import 'HomeScreens/portfolioScreen.dart';
import 'HomeScreens/traderProfileBasic.dart';
import 'HomeScreens/investedTraderProfile.dart';
import 'HomeScreens/checkWithdrawAndDeposit.dart';
import 'HomeScreens/transactionPopUp.dart';




final Map<String, WidgetBuilder> appRoutes = {

           '/': (context) => const SplashScreen(),  
        // This must match Navigator.pushNamed

           '/login': (context) => const LoginScreen(),
           '/signup': (context) => const SignupScreen(),
           '/role_selection': (context) => const RoleSelectionScreen(),
           '/verify': (context) => const VerifyIdentityScreen(), 
           '/face_verify': (context) => const FaceVerification(),
           '/cnic_verify': (context) => const Cnicverifyscreen(),
           '/investor_screen': (context) => const InvestorScreen(),
           '/trader_screen': (context) => const TradingStyleScreen(),
           
           '/profile_settings': (context) => ProfileSettingsScreen(
             isDarkMode: false, // Example value, replace with actual state management
             onThemeChanged: (bool value) {}, // Example callback, replace with actual logic
           ),

           '/edit_profile': (context) => const EditProfileScreen(),
           '/payment_method': (context) => const PaymentMethodScreen(),
           '/add_card': (context) => const AddCardScreen(),

           '/trader_equity': (context) => const TraderDashboard(),
           '/trader_profile': (context) => const TraderProfileScreen(),
           '/trader_metrics': (context) => const TraderMetricsScreen(),
           '/trader_profit': (context) => const TraderProfitScreen(),

            '/home': (context) => const HomeScreen(),
            '/search_trader': (context) => const SearchTradersScreen(),
            '/filter_screen': (context) => const FilterScreen(),
            '/invest_screen': (context) => const InvestScreen(),
            '/wallet': (context) => const  WalletScreen(),
            '/portfolio': (context) => const PortfolioScreen(),
            '/profile_basic': (context) => const TraderProfileOverviewScreen(),
            '/invested_trader_profile': (context) => const InvestedTraderProfileScreen(),
            '/withdraw': (context) => const WithdrawTransactionsScreen(),
            '/transaction_summary': (context) => const TransactionSummaryScreen(),
};