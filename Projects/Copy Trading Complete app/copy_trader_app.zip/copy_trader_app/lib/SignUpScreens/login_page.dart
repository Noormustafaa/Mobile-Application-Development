import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


class LoginScreen extends StatefulWidget{
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => LoginScreenState();

}

class LoginScreenState extends State<LoginScreen> {
  bool obscureText = true;

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = const Color(0xFF185C3C);
    final Color backgroundColor = const Color(0xFFFFFFFF);
    


    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          // Curved top background
          ClipPath(
            clipper: BottomWaveClipper(),
            child: Container(
              height: 0.4.sh,
              width: 1.sw,
              color: Color(0xFF217252),
            ),
          ),

          // Login content
          Padding(
            padding: EdgeInsets.only(top: 40.h), // Add space from top to show green curve
            child: SingleChildScrollView(
              padding: EdgeInsets.only(bottom: 40.h), // Add bottom padding for scrolling
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 350.w,
                    margin: EdgeInsets.symmetric(horizontal: 20.w), // Add horizontal margins
                    padding:
                    EdgeInsets.symmetric(horizontal: 24.w, vertical: 40.h),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24.r),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,

                      children: [
                         SizedBox(height:60.h),
                         Image.asset(
                          'assets/images/turtle_icon.png',
                          height: 72.h,
                          width: 73.w,
                        ),
                  
                        SizedBox(height: 8.h),

                        Text(
                          'Welcome Back to Turtle Traders',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16.sp,
                            fontFamily: 'Poppins',
                            color: Colors.black,

                          ),
                          
                        ),

                        SizedBox(height: 4.h),

                        Text(
                          'Login to continue',
                          style: TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 18.sp,
                            fontFamily: 'Arial',
                            color: Color(0xFFA0A0A1),
                          ),
                        
                        ),
                       SizedBox(height: 24.h),

                        // Email Field
                        SizedBox(
                          width: double.infinity,
                          height: 50.h,
                          child: TextField(
                            decoration: InputDecoration(
                              hintText: 'Email',
                              border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(12.r)),
                            ),
                          ),
                        ),

                       SizedBox(height: 16.h),

                        // Password Field
                        SizedBox(
                          width: double.infinity,
                          height: 50.h,
                         child: TextField(
                          obscureText: obscureText,
                          decoration: InputDecoration(
                            hintText: 'Password',
                            suffixIcon: IconButton(
                              icon: Icon(
                                obscureText ? Icons.visibility : Icons.visibility_off),
                                onPressed: () {
                                  setState(() {
                                   obscureText = !obscureText;
                              });
                              }
                          ),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.r)),
                          ),
                        ),),

//                    // Forget Password (Right aligned)
                      Align(
                        alignment: Alignment.centerRight,
                        child: TextButton(
                          onPressed: () {
                            //  Navigate to forget password page
                          },
                          child: Text(
                            "Forget Password?",
                            style: TextStyle(
                              color: Color(0xff6272A3), // Optional: customize
                              fontSize: 12.sp,
                              fontStyle: FontStyle.italic,
                              fontFamily: 'Poppins',
                              fontWeight: FontWeight.w400
                            ),
                          ),
                        )
                        ),

                        SizedBox(height: 24.h),

                        // Create Account Button
                        SizedBox(
                          width: double.infinity,
                          height: 54.h,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              elevation: 4,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.r)),
                            ),
                            onPressed: () {
                              Navigator.pushReplacementNamed(context, '/role_selection');
                            },
                            child: Text(
                              'Login',
                              style: TextStyle(fontWeight: FontWeight.w600,fontFamily: 'Poppins', fontSize: 19.sp,
                                  color: Colors.white),

                            ),
                          ),
                        ),
                        SizedBox(height: 16.h),

                        // OR Separator
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Or', style: TextStyle(color: Color(0xFFA0A0A1), fontSize: 14.sp)),
                          ],
                        ),
                        SizedBox(height: 16.h),

                        // Google Signup
                        SizedBox(
                          width: double.infinity,
                          height: 51.h,
                          child:OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.r)),
                           


                          ),
                          icon: Image.network(
                            'https://img.icons8.com/color/48/000000/google-logo.png',
                            width: 20.w,
                            height: 20.h,


                          ),
                          label: Text('Signin with Google', style: TextStyle(color: Color(0xff000000), fontFamily: 'Poppins', fontWeight: FontWeight.w300, fontSize: 16.sp)),
                          onPressed: () {},
                        ),),

                        SizedBox(height: 14.h),

                        // Already have account?
                        SizedBox(
                          width: double.infinity,
                          height: 36.h,
                          child: GestureDetector(
                                 onTap: () {
                                 Navigator.pushNamed(context, '/signup');
                                },
                                child: Text.rich(
                                textAlign: TextAlign.center,
                                TextSpan(
                                text: 'Dont have an account? ',
                                style: TextStyle(color: Color(0xFFA0A0A1), fontSize: 16.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w500),
                                children: [
                                  TextSpan(
                                    text: 'Sign up',
                                    style: TextStyle(
                                      color: Colors.blue,
                                      fontWeight: FontWeight.w500,
                                      fontSize: 16.sp,
                                      fontFamily: 'Poppins',
                                    ),
                                  ),
                                ],
                              ),
                            ),
                           ),),
                      ],
                    ),
                  ),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Custom clipper for curved top
class BottomWaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();

    path.lineTo(0, size.height - 50);
    path.quadraticBezierTo(
        size.width / 2, size.height, size.width, size.height - 50);
    path.lineTo(size.width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
