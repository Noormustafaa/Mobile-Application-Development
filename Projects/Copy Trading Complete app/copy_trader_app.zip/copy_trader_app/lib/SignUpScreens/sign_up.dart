import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

class SignupScreen extends StatefulWidget {
  const SignupScreen({super.key});

  @override
  State<SignupScreen> createState() => _SignupScreenState();
}

class _SignupScreenState extends State<SignupScreen> {
  bool obscureText = true;

  @override
  Widget build(BuildContext context) {
    final Color primaryColor = const Color(0xFF185C3C);
    final Color backgroundColor = const Color(0xFFFFFFFF);

    return Scaffold(
      backgroundColor: backgroundColor,
      body: Stack(
        children: [
          // Curved top background
          ClipPath(
            clipper: BottomWaveClipper(),
            child: Container(
              height: 0.4.sh,
              width: 1.sw,
              color: Color(0xFF217252),
            ),
          ),
          
          // Signup content
          Padding(
            padding: EdgeInsets.only(top: 40.h),
            child: SingleChildScrollView(
              padding: EdgeInsets.only(bottom: 40.h),
              child: Stack(
                clipBehavior: Clip.none,
                children: [
                  Container(
                    width: 340.w,
                    margin: EdgeInsets.symmetric(horizontal: 20.w),
                    padding:
                    EdgeInsets.symmetric(horizontal: 24.w, vertical: 40.h ),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(24.r),
                    ),
                    child: Column(
                      mainAxisSize: MainAxisSize.min,

                      children: [
                      SizedBox(height: 60.h),
                       // Top Turtle Icon
                      Image.asset(
                          'assets/images/turtle_icon.png',
                          height: 72.h,
                          width: 73.w,
                        ),
                  
                        SizedBox(height: 8.h),

                        // Welcome Text
                        Text(
                          'Welcome to Turtle Traders',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontFamily: 'Poppins',
                            fontSize: 20.sp,
                            color: Colors.black,
                            
                            
                          ),
                        ),
                        
                        SizedBox(height: 4.h),
                        Text(
                          'Signup to create your Account',
                          style: TextStyle(
                            fontWeight: FontWeight.w400,
                            fontSize: 18.sp,
                            fontFamily: 'Arial',
                            color: Color(0xFFA0A0A1), // Grey color for subtitle
                          ),
                          
                        ),
                        SizedBox(height: 24.h),

                        // Email Field
                        SizedBox(
                          width: 337.w,
                          height: 50.h,
                          child:
                        TextField(
                          keyboardType: TextInputType.emailAddress,
                          decoration: InputDecoration(
                            hintText: 'Email',
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.r)),
                                
                           ),
                        )),

                        SizedBox(height: 16.h),
                        // Phone Field (with country dropdown and flag)
                        IntlPhoneField(
                          decoration: InputDecoration(
                            hintText: 'Phone',
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12.r),
                            ),
                          ),
                          initialCountryCode: 'PK', // Default to Pakistan
                          onChanged: (phone) {
                            print(phone.completeNumber); // Full number with country code
                          },
                        ),


                        // Password Field
                        SizedBox(
                          width: 337.w,
                          height: 50.h,
                          child:TextField(
                          obscureText: obscureText,
                          decoration: InputDecoration(
                            hintText: 'Password',
                            suffixIcon: IconButton(
                              icon:  Icon(
                                obscureText ? Icons.visibility : Icons.visibility_off,
                              ),
                              onPressed: () {
                                setState(() {
                                  obscureText = !obscureText;
                                });
                              },
                            ),
                            border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(12.r)),
                            
                          ),
                        )),

                        SizedBox(height: 24.h),

                        // Create Account Button
                        SizedBox(
                          width: 337.w,
                          height: 54.h,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: primaryColor,
                              elevation: 4,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12.r)),
                            ),
                            onPressed: () {
                              Navigator.pushReplacementNamed(context, '/role_selection');
                            },
                            child: Text(
                              'Create Account',
                              style: TextStyle(fontWeight: FontWeight.w600, fontFamily: 'Poppins', fontSize: 19.sp,
                              color: Colors.white),

                            ),
                          ),
                        ),
                        SizedBox(height: 16.h),

                        // OR Separator
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('Or', style: TextStyle(color: Color(0xFFA0A0A1), fontSize: 14.sp)),
                          ],
                        ),
                        SizedBox(height: 16.h),


                        // Google Signup
                        SizedBox(
                          width: 340.w,
                          height: 51.h,
                          child: OutlinedButton.icon(
                          style: OutlinedButton.styleFrom(
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12.r)),
                          ),
                          icon: Image.network(
                            'https://img.icons8.com/color/48/000000/google-logo.png',
                            height: 35.09870147705078.h,
                            width: 35.09870147705078.w,
                          ),
                          label: Text('Signup with Google', style: TextStyle(color: Color(0xff000000), fontFamily: 'Poppins', fontWeight: FontWeight.w300, fontSize: 16.sp)),
                          onPressed: () {}, // move to route when click the google icon
                        ),),
                      

                        SizedBox(height: 16.h),

                        // Already have account?
                        SizedBox(
                        width: 362.w,
                        height: 36.h,
                        child: GestureDetector(
                                 onTap: () {
                                 Navigator.pushNamed(context, '/login');
                                },
                            child: Text.rich(
                              textAlign: TextAlign.center,
                              TextSpan(
                                text: 'Dont have an account? ',
                                style: TextStyle(color: Color(0xFFA0A0A1), fontSize: 16.sp, fontFamily: 'Poppins', fontWeight: FontWeight.w500),
                                children: [
                                  TextSpan(
                                    text: 'Log In',
                                    style: TextStyle(
                                      color: Colors.blue,
                                      fontWeight: FontWeight.w500,
                                      fontFamily: 'Poppins',
                                      fontSize: 16.sp,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                           ),),
                      ],
                    ),
                  ),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Custom clipper for curved top
class BottomWaveClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();

    path.lineTo(0, size.height - 50);
    path.quadraticBezierTo(
        size.width/ 2, size.height, size.width, size.height - 50);
    path.lineTo(size.width, 0);
    path.close();

    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}
