import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});


  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
    
 @override
void initState() {
    super.initState();

    // Navigate to SignupScreen after 3 seconds
    Future.delayed(const Duration(seconds: 3), () {
      // if user is new go to login page
      // if user is already registered go to home page
      // For now, we will just navigate to login page
      Navigator.pushReplacementNamed(context, '/login');
    });
  }


 @override
Widget build(BuildContext context) {
  return Scaffold(
    body: Container(
      color: const Color(0xFF185C3C),
      child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // Center vertically
          children: [
            
            // Turtle image and text
            Image.asset(
              'assets/images/logo.png',
              height: 57.h, // Adjust height as needed
              width: 49.58536148071289.w, // Adjust width as needed
            ),
            SizedBox(height: 5.h), // Spacing between image and text
            Text(
              "Turtle Trades",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white,
                fontSize: 28.sp,
                fontWeight: FontWeight.bold,
              ),
            ),

            SizedBox(height: 10.h), // Spacing between texts

            Text(
              "Where Equity meets Talent",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: Colors.white70,
                fontSize: 18.sp,
              ),
            ),
          ],
        ),
      ),
    ),
  );
}
}








