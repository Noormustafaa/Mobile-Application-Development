import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AddCardScreen extends StatefulWidget {

  const AddCardScreen({super.key});

  @override
  _AddCardScreenState createState() => _AddCardScreenState();
}


class _AddCardScreenState extends State<AddCardScreen> {
  final TextEditingController nameController = TextEditingController();
  final TextEditingController cardNumberController = TextEditingController();
  final TextEditingController expiryDateController = TextEditingController();
  final TextEditingController cvvController = TextEditingController();

  final  buttonfont = TextStyle(fontSize: 16, fontWeight: FontWeight.w600,color: Colors.white, fontFamily: 'Poppins');
  final bodyfont = TextStyle(fontSize: 14, fontWeight: FontWeight.w500, color: Colors.black, fontFamily: 'Poppins');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
     appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black, size: 24.sp),
          onPressed: () {
            Navigator.pushNamed(context, '/payment_method');
          },
        ),
        title: Text(
          'Payment Methods',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18.sp,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
      ),

      body: SingleChildScrollView(
        padding: EdgeInsets.all(16),
        child: Center(
          child: Container(
            padding: EdgeInsets.all(20),
            width: 1.w > 500.w ? 400.w : double.infinity,
            decoration: BoxDecoration(
              border: Border.all(color: Colors.black12),
              borderRadius: BorderRadius.circular(16.r),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Add Credit / Debit Card",
                  style: buttonfont.copyWith(color: Colors.black,),
                ),

                SizedBox(height: 20.h),

                buildTextField("Cardholder name", "John dow", nameController),

                SizedBox(height: 16.h),
                buildTextField("Card Number", "1234 5678 9012 3456", cardNumberController),

                SizedBox(height: 16.h),
                buildTextField("Expiry Date", "MM/YY", expiryDateController),

                SizedBox(height: 16.h),
                buildTextField("CVV", "123", cvvController, obscureText: true),

                SizedBox(height: 30.h),
                
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      // Handle Add Card logic

                      //then move to profile settings screen
                      Navigator.pushNamed(context, '/profile_settings');
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Color(0xFF0B5638), // dark green
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30),
                      ),
                      elevation: 4,
                      minimumSize: Size(double.infinity, 50.h),
                    ),
                    child: Text(
                      "Add Card",
                      style: buttonfont,
                  ),
                ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget buildTextField(
      String label,
      String hint,
      TextEditingController controller, {
        bool obscureText = false,
      }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: bodyfont),
        SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: obscureText,
          decoration: InputDecoration(
            hintText: hint,
            contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
          ),
        ),
      ],
    );
  }
}
