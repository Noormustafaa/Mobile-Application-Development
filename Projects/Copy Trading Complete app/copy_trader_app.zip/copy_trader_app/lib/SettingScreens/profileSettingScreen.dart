import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class ProfileSettingsScreen extends StatefulWidget {
  final bool isDarkMode;
  final ValueChanged<bool> onThemeChanged;

  const ProfileSettingsScreen({
    super.key,
    required this.isDarkMode,
    required this.onThemeChanged,
  });

  @override
  State<ProfileSettingsScreen> createState() => _ProfileSettingsScreenState();
}

class _ProfileSettingsScreenState extends State<ProfileSettingsScreen> {
  bool isDemoOn = true;
  int selectedIndex = 0;
  final Color primaryColor = const Color(0xFF217252);
  final namefont = TextStyle(fontSize: 20.sp, fontWeight: FontWeight.w700, fontFamily: 'Poppins', color: Colors.white);
  final emailfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, fontFamily: 'Poppins', color: Colors.white);
  final numberfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, fontFamily: 'Arial', color: Colors.white70);
  final bodyfont = TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w400, fontFamily: 'Arial', color: Colors.black);
  final bottomNavigationBarfont = TextStyle(fontSize: 10.sp, fontWeight: FontWeight.w400, fontFamily: 'Poppins');

   int _selectedIndex=0;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
       backgroundColor: Colors.white,
      bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20.w),
          child: Column(
            children: [
              // Profile Card
              Container(
                width: double.infinity,
                padding: EdgeInsets.all(20.w),
                decoration: BoxDecoration(
                  color: Color(0xFF217252),
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Column(
                  children: [
                    CircleAvatar(
                      radius: 35.r,
                      //backgroundImage: AssetImage('assets/images/profile_picture.png'), // Replace with your image
                    ),
                    SizedBox(height: 10.h),
                    Text(
                      'Maria Khan',           //change the name here with user name
                      style: namefont,
                    ),
                    Text(
                      'abctraders123@gmail.com',
                      style: emailfont,
                    ),
                    Text(
                      '+91 94449771**',
                      style: numberfont,
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10.h),

              // Demo Switch
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Text(
                    'Demo',
                    style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, fontFamily: 'Poppins', color: Colors.black54),
                  ),
                  Switch(
                    value: widget.isDarkMode,
                    onChanged: widget.onThemeChanged,
                    activeColor: Colors.teal,
                  ),
                ],
              ),
              SizedBox(height:10.h),

              // Options
              _buildListTile(
                Icons.person_outline,
                'Profile',
                    () {
                  Navigator.pushNamed(context, '/edit_profile');
                },
              ),
              _buildListTile(
                Icons.dark_mode_outlined,
                'Dark mode',
                null,
                trailing: Switch(
                  value: widget.isDarkMode,
                  onChanged: widget.onThemeChanged,
                  activeColor: Color(0xFF0B5638), // dark green
                ),
              ),
              _buildListTile(Icons.account_balance, 'payment_method', ()
                {Navigator.pushNamed(context, '/payment_method');}),
              _buildListTile(Icons.verified_user, 'KYC Verification', () {
                 // Navigator.pushNamed(context, '/KYCVerification');
              }),
              _buildListTilelogout(
                Icons.logout,
                'Logout',
                    () {},
                iconColor: Color(0xFFD90429), // dark green
             
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildListTile(IconData icon, String title, VoidCallback? onTap,
      {Widget? trailing, Color? iconColor, Color? textColor}) {
    return Column(
      children: [
        ListTile(
          onTap: onTap,
          leading: Icon(icon, color: iconColor ?? Colors.teal, size: 24.sp),
          title: Text(
            title,
            style: TextStyle(color: textColor ?? Colors.black, fontSize: 18.sp, fontFamily: 'Arial', fontWeight: FontWeight.w400),
          ),
          trailing: trailing ?? Icon(Icons.chevron_right, size: 20.sp),
        ),
        Divider(),
      ],
    );
  }

  Widget _buildListTilelogout(IconData icon, String title, VoidCallback? onTap,
      {Color? iconColor, Color? textColor}) {
    return Column(
      children: [
        ListTile(
          onTap: onTap,
          leading: Icon(icon, color: iconColor ?? Colors.teal, size: 24.sp),
          title: Text(
            title,
            style: TextStyle(color: textColor ?? Colors.black, fontSize: 18.sp, fontFamily: 'Arial', fontWeight: FontWeight.w400),
          ),
        ),
        Divider(),
      ],
    );
  }
}
