import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  int selectedIndex = 0;

  final Color greenColor = const Color(0xFF0B5638);
   int _selectedIndex=0;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: Icon(Icons.arrow_back, color: Colors.black, size: 24.sp),
            onPressed: () {
              Navigator.pushNamed(context, '/profile_settings');
            },
          ),
          
          title: Text(
            'Profile Settings',
            style: TextStyle(
                color: Colors.black,
                fontWeight: FontWeight.w700,
                fontFamily: 'Poppins',
                fontSize: 24.sp),
          ),
          centerTitle: true,
        ),
        body: Padding(
          padding: EdgeInsets.symmetric(horizontal: 24.w),
          child: ListView(
            children: [
              SizedBox(height: 20.h),
              Center(
                child: Stack(
                  alignment: Alignment.bottomRight,
                  children: [
                    CircleAvatar(
                      radius: 50.r,
                      backgroundColor: Colors.grey[200],
                      child:
                      Icon(Icons.person, size: 60.sp, color: Colors.black),
                    ),
                    CircleAvatar(
                      radius: 14.r,
                      backgroundColor: Color(0xFF028643),
                      child: Icon(Icons.camera_alt,
                          color: Colors.white, size: 16.sp),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 30.h),
              buildTextField("Name", "John Doe"),
              buildTextField("Email", "johndoe@gmail.com"),
              buildTextField("Phone no", "0321111*****"),
              buildTextField("Date of Birth", "12/June/2022"),
              SizedBox(height: 30.h),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () {
                    // Handle Save Changes logic
                    Navigator.pushNamed(context, '/profile_settings');
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: greenColor,
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8.r)),

                   elevation: 4,
                    minimumSize: Size(double.infinity, 52.h),
                  ),
                  child: Text(
                    "Save Changes",
                    style: TextStyle(
                        fontSize: 18.sp,
                        fontWeight: FontWeight.w700,
                        fontFamily: 'Poppins',
                        color: Colors.white),
                  ),
                ),
              ),
              SizedBox(height: 20.h),
            ],
          ),
        ),
        bottomNavigationBar: CustomBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped)
      );
  }

  Widget buildTextField(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: TextStyle(
                color: Color(0xFFBEBCBC),
                fontSize: 16.sp,
                fontFamily: 'Poppins',
                fontWeight: FontWeight.w500)),
        SizedBox(height: 5.h),
        TextFormField(
          initialValue: value,
          decoration: InputDecoration(
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8.r),
            ),
            contentPadding:
            EdgeInsets.symmetric(horizontal: 12.w, vertical: 14.h),
          ),
        ),
        SizedBox(height: 20.h),
      ],
    );
  }
}
