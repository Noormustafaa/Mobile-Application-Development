import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class PaymentMethodScreen extends StatefulWidget {
  const PaymentMethodScreen({super.key});

  @override
  State<PaymentMethodScreen> createState() => _PaymentMethodScreenState();
}

class _PaymentMethodScreenState extends State<PaymentMethodScreen> {
  final Color greenColor = const Color(0xFF0B5638);
  int selectedIndex = 0;

  final visaendingfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400,  color: Colors.black, fontFamily: 'Arial');
  final datefont = TextStyle(fontSize: 8.sp, fontWeight: FontWeight.w400,  color: Color(0xFF717171), fontFamily: 'Arial');
  final buttonfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w500, color: Colors.white, fontFamily: 'Poppins');
  
   int _selectedIndex=0;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.white,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Colors.black, size: 24.sp),
          onPressed: () {
            Navigator.pushNamed(context, '/profile_settings');
          },
        ),
        title: Text(
          'Payment Methods',
          style: TextStyle(
            color: Colors.black,
            fontSize: 18.sp,
            fontWeight: FontWeight.w700,
            fontFamily: 'Poppins',
          ),
        ),
        centerTitle: true,
      ),
      body: Padding(
        padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 15.h),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.r),
              ),
              elevation: 2,
              color: Colors.white,
              child: Padding(
                padding: EdgeInsets.all(20.r),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "Payment Methods",
                      style: TextStyle(
                        fontSize: 16.sp,
                        fontWeight: FontWeight.w600,
                        fontFamily: 'Poppins',
                      ),
                    ),
                    SizedBox(height: 4.h),
                    Text(
                      "Manage your payment methods for deposits\nand withdrawals",
                      style: TextStyle(
                        color: Color(0xFF747272),
                        fontSize: 12.sp,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w400
                      ),
                    ),
                    SizedBox(height: 16.h),
                    paymentCard(),
                    Divider(),
                    paymentCard(),
                    SizedBox(height: 20.h),
                    Row(
                      children: [
                        buildGreenButton("Add Card"),
                        buildGreenButton("Add Bank"),
                      ],
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: CustomBottomNavBar(
        selectedIndex: _selectedIndex,
        onItemTapped: _onNavItemTapped,
      ),
    );
  }

  Widget paymentCard() {
    return Row(
      children: [
        FaIcon(FontAwesomeIcons.ccVisa, size: 20.sp),
        SizedBox(width: 10.w),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              RichText(
                text: TextSpan(
                  text: 'Visa ending in ',
                  style: visaendingfont,
                  children: <TextSpan>[
                    TextSpan(
                      text: '4242',
                      style:visaendingfont
                    ),
                  ],
                ),
              ),
              SizedBox(height: 4.h),
              Text(
                'Expires on 24/July/2025',
                 style: datefont,
              ),
            ],
          ),
        ),
        IconButton(
          icon: Icon(Icons.delete_outline, color: Colors.black, size: 22.sp),
          onPressed: () {
            // Handle delete action
          },
        )
      ],
    );
  }

  Widget buildGreenButton(String text) {
    return Expanded(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 4.w),
        child: ElevatedButton(
          onPressed: () {
            if (text == "Add Card") {
              Navigator.pushNamed(context, '/add_card');
            }
            // You can add more conditions here for other buttons
            else if (text == "Add bank") {
              Navigator.pushNamed(context, '/TraderDashboard');
            }
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: greenColor,
            padding: EdgeInsets.symmetric(vertical: 10.h),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(6.r),
            ),
          ),
          child: Text(
            text,
            style: buttonfont,
          ),
        ),
      ),
    );
  }

}
