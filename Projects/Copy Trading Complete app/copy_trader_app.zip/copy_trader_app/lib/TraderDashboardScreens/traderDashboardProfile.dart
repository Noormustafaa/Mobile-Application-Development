import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class TraderProfileScreen extends StatefulWidget {
  const TraderProfileScreen({super.key});


  @override
  State<TraderProfileScreen> createState() => _TraderProfileScreenState();
}

class _TraderProfileScreenState extends State<TraderProfileScreen> {
  final TextEditingController nameController = TextEditingController(text: "John dow");
  final TextEditingController experienceController = TextEditingController(text: "John dow");
  final TextEditingController bioController = TextEditingController(text: "Dummy text");
  final TextEditingController strategyController = TextEditingController(text: "Scalping and Swing Trading");

  final titlefont = TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w700, fontFamily: 'Poppins', color: Colors.black);
  final subtitlefont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w400, color: Color(0xFF686868), fontFamily: 'Arial');
  final textfieldfont = TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400, color: Color(0xFF686868), fontFamily: 'Arial');
  String selectedTab = 'Profile'; // Track which tab is selected
  
  int _selectedIndex = 4;

  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
        break;
      case 4:
        Navigator.pushNamed(context, '/trader_profile');
    }
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
               Navigator.pushNamed(context, '/trader_equity'); // Go back to previous screen
          },
        ),
       ),
       
      bottomNavigationBar: DashboardBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Trader Dashboard",
                  style: titlefont),
              SizedBox(height: 4.h),
              Text("Manage your trading profile and track performance",
                  style: subtitlefont),
              SizedBox(height: 10.h),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Text("Verified Trader",
                    style: subtitlefont.copyWith(color: Color(0xFF00A968), fontSize: 12.sp, fontWeight: FontWeight.w700)),
              ),
              SizedBox(height: 25.h),
              Wrap(
                spacing: 12.w,
                runSpacing: 10.h,
                children: [
                  _buildInfoCard('Total Equity', '\$452,000', Icons.attach_money),
                  _buildInfoCard('Monthly Growth', '+8.4%', Icons.trending_up, green: true),
                  _buildInfoCard('Followers', '247', Icons.people),
                  _buildInfoCard('Monthly Profit', '\$15,249', Icons.stacked_line_chart, green: true),
                ],
              ),
              SizedBox(height: 20.h),

              // Tabs
                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.r),
                    color: Colors.white, // Changed from grey to white
                    border: Border.all(color: Colors.grey.shade200), // Added border for definition
                  ),
                  child: Column(
                    children: [
                      // First row - Profile and Equity
                      Row(
                        children: [
                          _buildTabButton('Profile'),
                          SizedBox(width: 8.w),
                          _buildTabButton('Equity'),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      // Second row - Metrics and Profit
                      Row(
                        children: [
                          _buildTabButton('Metrics'),
                          SizedBox(width: 8.w),
                          _buildTabButton('Profit'),
                        ],
                      ),
                    ],
                  ),
                ),

              SizedBox(height: 24.h),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text("Profile Settings",
                      style: titlefont.copyWith(fontWeight: FontWeight.w600)),
                  CircleAvatar(
                    radius: 16.r,
                    backgroundColor: Colors.green.shade100,
                    child: const Icon(Icons.edit, size: 16, color: Colors.green),
                  )
                ],
              ),
               SizedBox(height: 16.h),
              _buildTextField("Display Name", nameController),
              _buildTextField("Experience", experienceController),
              _buildTextField("Bio", bioController),
              _buildTextField("Trading Strategy", strategyController),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, IconData icon, {bool green = false}) {
    return Container(
      width: 160.w,
      padding: EdgeInsets.all(14.r),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12.r),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: subtitlefont.copyWith(fontSize: 12.sp)),
          SizedBox(height: 6.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(value,
                  style: titlefont.copyWith(
                      fontSize: 18.sp,
                      color: green ? Colors.green : Colors.black)),
              Icon(icon, color: green ? Colors.green : Colors.black),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String text) {
    bool isActive = selectedTab == text;
    
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedTab = text;
          });
          if (selectedTab == 'Equity') {
              Navigator.pushNamed(context, '/trader_equity');
          } else if (selectedTab == 'Profile') {
            Navigator.pushNamed(context, '/trader_profile');
          } else if (selectedTab == 'Metrics') {
            Navigator.pushNamed(context, '/trader_metrics');
          } else if (selectedTab == 'Profit') {
            Navigator.pushNamed(context, '/trader_profit');
          } 
        },
        child: Container(
          height: 40.h,
          decoration: BoxDecoration(
            color: isActive ? Colors.green.shade800 : Colors.white,
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(
              color: isActive ? Colors.green.shade800 : Colors.white,
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 1,
                offset: Offset(0, 1),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            text,
            style: subtitlefont.copyWith(
              color: isActive ? Colors.white : Color(0xFF706D6D),
              fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(String label, TextEditingController controller) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: textfieldfont),
        SizedBox(height: 8.h),
        TextField(
          controller: controller,
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 14.h),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12.r)),
          ),
        ),
        SizedBox(height: 16.h),
      ],
    );
  }
}
