import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/charts/line_chart.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class TraderDashboard extends StatefulWidget {
  const TraderDashboard({super.key});

  @override
  State<TraderDashboard> createState() => _TraderDashboardState();
}

class _TraderDashboardState extends State<TraderDashboard> {
  final titlefont = TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w700, fontFamily: 'Poppins', color: Colors.black);
  final subtitlefont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w400, color: Color(0xFF686868), fontFamily: 'Arial');
  String selectedTab = 'Equity'; // Track which tab is selected
  

  final primaryColor = Color(0xFF0B5638);

  //remove this when you have actual data
  final List<FlSpot> liveChartData = [
  FlSpot(0, 8000),
  FlSpot(1, 10000),
  FlSpot(2, 9000),
  FlSpot(3, 7000),
  FlSpot(4, 3000),
  FlSpot(5, 5000),
  FlSpot(6, 10000),
  FlSpot(7, 8000),
  FlSpot(8, 9000),
  FlSpot(9, 11000),
  FlSpot(10, 7500),
  FlSpot(11, 2500),
];


  int _selectedIndex = 4;

  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
        break;
      case 4:
        Navigator.pushNamed(context, '/trader_equity');
    }
  }

  @override
  Widget build(BuildContext context) {
    
    return Scaffold(
      backgroundColor: Colors.white,
      bottomNavigationBar: DashboardBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped),
      body: SafeArea(
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(height: 20.h),
                Text('Trader Dashboard', style: titlefont),

                SizedBox(height: 4.h),
                Text('Manage your trading profile and track performance', style: subtitlefont),

                SizedBox(height: 10.h),

                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12.w, vertical: 4.h),
                  decoration: BoxDecoration(
                    color: Colors.green.shade100,
                    borderRadius: BorderRadius.circular(20.r),
                  ),
                  child: Text('Verified Trader',
                      style: TextStyle( color: Color(0xFF00A968), fontSize: 12.sp, fontFamily: 'Arial', fontWeight: FontWeight.w700)),
                ),

                SizedBox(height: 25.h),
                Wrap(
                  spacing: 10.w,
                  runSpacing: 10.h,
                  children: [
                    _buildInfoCard('Total Equity', '\$452,000', Icons.attach_money,),
                    _buildInfoCard('Monthly Growth', '+8.4%', Icons.trending_up, green: true),
                    _buildInfoCard('Followers', '247', Icons.people, ),
                    _buildInfoCard('Monthly Profit', '\$15,249', Icons.trending_up, green: true),
                  ],
                ),
                SizedBox(height: 20.h),

                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.r),
                    color: Colors.white, // Changed from grey to white
                    border: Border.all(color: Colors.grey.shade200), // Added border for definition
                  ),
                  child: Column(
                    children: [
                      // First row - Profile and Equity
                      Row(
                        children: [
                          _buildTabButton('Profile'),
                          SizedBox(width: 8.w),
                          _buildTabButton('Equity'),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      // Second row - Metrics and Profit
                      Row(
                        children: [
                          _buildTabButton('Metrics'),
                          SizedBox(width: 8.w),
                          _buildTabButton('Profit'),
                        ],
                      ),
                    ],
                  ),
                ),
                
                SizedBox(height: 20.h),

                Container(
                   width: double.infinity,

                  padding: EdgeInsets.all(16.r),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12.r),
                    border: Border.all(color: Colors.grey.shade200),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Equity Curve', style: titlefont.copyWith(fontSize: 16.sp)),
                      Text('Track your Portfolio growth over time', style: subtitlefont),

                      SizedBox(height: 20.h),
                      TraderLineChart(
                   spots: liveChartData, // <-- this should come from API, provider, or state
                  )
                  ]),),
              ],
            ),
          ),
        ),
      );
  }

  Widget _buildInfoCard(String title, String value, IconData icon, {bool green = false}) {
    return Container(
      width: 160.w,
      padding: EdgeInsets.all(14.r),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12.r),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,
              style: subtitlefont),

          SizedBox(height: 6.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(value,
                  style: titlefont.copyWith(
                      fontSize: 18.sp,
                      color: green ? Colors.green : Colors.black)),
              Icon(icon, color:  Colors.green),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String text) {
    bool isActive = selectedTab == text;
    
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedTab = text;
          });
          if (selectedTab == 'Equity') {
              Navigator.pushNamed(context, '/trader_equity');
          } else if (selectedTab == 'Profile') {
            Navigator.pushNamed(context, '/trader_profile');
          } else if (selectedTab == 'Metrics') {
            Navigator.pushNamed(context, '/trader_metrics');
          } else if (selectedTab == 'Profit') {
            Navigator.pushNamed(context, '/trader_profit');
          } 
        },
        child: Container(
          height: 40.h,
          decoration: BoxDecoration(
            color: isActive ? Colors.green.shade800 : Colors.white,
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(
              color: isActive ? Colors.green.shade800 : Colors.white,
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 1,
                offset: Offset(0, 1),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            text,
            style: subtitlefont.copyWith(
              color: isActive ? Colors.white : Color(0xFF706D6D),
              fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }
}
