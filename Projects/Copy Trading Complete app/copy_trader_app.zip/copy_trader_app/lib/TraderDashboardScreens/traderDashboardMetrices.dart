import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:copy_trader_app/bottomNavigationBar.dart';

class TraderMetricsScreen extends StatefulWidget {
  const TraderMetricsScreen({super.key});

  @override
  State<TraderMetricsScreen> createState() => _TraderMetricsScreenState();
}

class _TraderMetricsScreenState extends State<TraderMetricsScreen> {

  final titlefont = TextStyle(fontSize: 18.sp, fontWeight: FontWeight.w700, fontFamily: 'Poppins', color: Colors.black);
  final subtitlefont = TextStyle(fontSize: 14.sp, fontWeight: FontWeight.w400, color: Color(0xFF686868), fontFamily: 'Arial');
  String selectedTab = 'Metrics'; // Track which tab is selected

  int _selectedIndex = 4;
  void _onNavItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });

    switch (index) {
      case 0:
        Navigator.pushNamed(context, '/home');
        break;
      case 1:
        Navigator.pushNamed(context, '/search_trader');
        break;
      case 2:
        Navigator.pushNamed(context, '/portfolio');
        break;
      case 3:
        Navigator.pushNamed(context, '/wallet');
        break;
      case 4:
        Navigator.pushNamed(context, '/trader_metrics');
    }
  } // Assuming Dashboard is selected by default

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.white,
          leading: IconButton(
            icon: const Icon(Icons.arrow_back, color: Colors.black),
            onPressed: () {
               Navigator.pushNamed(context, '/trader_equity'); // Go back to previous screen
          },
        ),
       ),

      bottomNavigationBar:  DashboardBottomNavBar(selectedIndex: _selectedIndex, onItemTapped: _onNavItemTapped),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 12.h),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text("Trader Dashboard", style: titlefont),

              SizedBox(height: 4.h),

              Text("Manage your trading profile and track performance", style: subtitlefont),
              SizedBox(height: 10.h),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: Colors.green.shade100,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text("Verified Trader",
                    style:   subtitlefont.copyWith(color: Color(0xFF00A968), fontSize: 12.sp, fontWeight: FontWeight.w700)),
              ),
              SizedBox(height: 25.h),

              Wrap(
                spacing: 12.w,
                runSpacing: 10.h,
                children: [
                  _buildInfoCard('Total Equity', '\$452,000', Icons.attach_money),
                  _buildInfoCard('Monthly Growth', '+8.4%', Icons.trending_up, green: true),
                  _buildInfoCard('Followers', '247', Icons.people),
                  _buildInfoCard('Monthly Profit', '\$15,249', Icons.stacked_line_chart, green: true),
                ],
              ),
              SizedBox(height: 20.h),

              // Tabs
                Container(
                  padding: EdgeInsets.all(8.w),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12.r),
                    color: Colors.white, // Changed from grey to white
                    border: Border.all(color: Colors.grey.shade200), // Added border for definition
                  ),
                  child: Column(
                    children: [
                      // First row - Profile and Equity
                      Row(
                        children: [
                          _buildTabButton('Profile'),
                          SizedBox(width: 8.w),
                          _buildTabButton('Equity'),
                        ],
                      ),
                      SizedBox(height: 8.h),
                      // Second row - Metrics and Profit
                      Row(
                        children: [
                          _buildTabButton('Metrics'),
                          SizedBox(width: 8.w),
                          _buildTabButton('Profit'),
                        ],
                      ),
                    ],
                  ),
                ),

              SizedBox(height: 24.h),
              Text("Performance Metrics", style: titlefont.copyWith(fontWeight: FontWeight.w600)),
              SizedBox(height: 16.h),

              Wrap(
                spacing: 10,
                runSpacing: 10,
                children: [
                  _buildMetricCard("Win Rate", "78%", icon: Icons.emoji_events, color: Colors.green),
                  _buildMetricCard("Profit Factor", "2.14", icon: Icons.bar_chart, color: Colors.green),
                  _buildMetricCard("Sharp Ratio", "1.67", icon: Icons.show_chart, color: Colors.green),
                  _buildMetricCard("ROI", "+42.8%", icon: Icons.trending_up, color: Colors.green),
                  _buildMetricCard("Max Drawdown", "-8.2%", icon: Icons.trending_down, color: Colors.red),
                  _buildMetricCard("Total Trades", "127", icon: Icons.bolt, color: Colors.green),
                  _buildMetricCard("Avg Win", "\$285.5", icon: Icons.arrow_upward, color: Colors.green),
                  _buildMetricCard("Avg Loss", "\$142.3", icon: Icons.arrow_downward, color: Colors.red),
                ],
              ),

              SizedBox(height: 20.h),
              _buildStatRow("Best Trade", "1250.4", green: true),
              _buildStatRow("Worst Trade", "890", red: true),
              _buildStatRow("Risk Reward", "2.3:1"),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoCard(String title, String value, IconData icon, {bool green = false}) {
    return Container(
      width: 160.w,
      padding: EdgeInsets.all(14.r),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade200),
        borderRadius: BorderRadius.circular(12.r),
        color: Colors.white,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title,  style: subtitlefont.copyWith(fontSize: 12.sp)),
          SizedBox(height: 6.h),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(value,
                  style: titlefont.copyWith(
                      fontSize: 18.sp,
                      color: green ? Colors.green : Colors.black)),
              Icon(icon, color: green ? Colors.green : Colors.black),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabButton(String text) {
    bool isActive = selectedTab == text;
    
    return Expanded(
      child: GestureDetector(
        onTap: () {
          setState(() {
            selectedTab = text;
          });
          if (selectedTab == 'Equity') {
              Navigator.pushNamed(context, '/trader_equity');
          } else if (selectedTab == 'Profile') {
            Navigator.pushNamed(context, '/trader_profile');
          } else if (selectedTab == 'Metrics') {
            Navigator.pushNamed(context, '/trader_metrics');
          } else if (selectedTab == 'Profit') {
            Navigator.pushNamed(context, '/trader_profit');
          } 
        },
        child: Container(
          height: 40.h,
          decoration: BoxDecoration(
            color: isActive ? Colors.green.shade800 : Colors.white,
            borderRadius: BorderRadius.circular(10.r),
            border: Border.all(
              color: isActive ? Colors.green.shade800 : Colors.white,
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 1,
                offset: Offset(0, 1),
              ),
            ],
          ),
          alignment: Alignment.center,
          child: Text(
            text,
            style: subtitlefont.copyWith(
              color: isActive ? Colors.white : Color(0xFF706D6D),
              fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
            ),
          ),
        ),
      ),
    );
  }


  Widget _buildMetricCard(String title, String value,
      {required IconData icon, required Color color}) {
    return Container(
      width: 160.w,
      padding: EdgeInsets.all(14.r),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(color: Colors.grey.shade300),
        color: Colors.white,
      ),
      child: Column(
        children: [
          Icon(icon, color: color),
          SizedBox(height: 6.h),
          Text(title,
              style: subtitlefont),
          Text(value,
              style: titlefont.copyWith(fontSize: 16.sp, color: color)),
        ],
      ),
    );
  }

  Widget _buildStatRow(String label, String value, {bool green = false, bool red = false}) {
    final color = green
        ? Colors.green
        : red
        ? Colors.red
        : Colors.black;

    return Padding(
      padding: EdgeInsets.only(bottom: 12.h),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 16.w, vertical: 12.h),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12.r),
          border: Border.all(color: Colors.grey.shade200),
        ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: subtitlefont.copyWith(color: Colors.black)),
          Text(value,
              style: subtitlefont.copyWith( color: color,)),
      ],
      ),),
    );
  }
}
