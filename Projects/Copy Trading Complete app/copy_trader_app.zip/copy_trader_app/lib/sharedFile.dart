
class SharedData {
  static String? selectedRole;
}
